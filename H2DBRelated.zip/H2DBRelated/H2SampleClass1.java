import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class H2SampleClass1 {

	 static final String JDBC_DRIVER = "org.h2.Driver";   
	 //DB_CLOSE_DELAY=-1
	 //jdbc:h2:~/test
	 static final String DB_URL = "jdbc:h2:~/test";  
	 //   static final String DB_URL = "jdbc:h2:test;DB_CLOSE_DELAY=-1";  
	   // static final String DB_URL = "jdbc:h2:~/";  
	 // static final String DB_URL = "jdbc:h2:~";  
	 //  static final String DB_URL = "jdbc:h2:mem:test";  
	   //  Database credentials 
	   static final String USER = "sa"; 
	   static final String PASS = "h2@123456"; 
	   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		   
		   Connection conn = null; 
		      Statement stmt = null; 
		      System.out.println("hello");
		      try { 
		         // STEP 1: Register JDBC driver 
		         Class.forName(JDBC_DRIVER); 
		             
		         //STEP 2: Open a connection 
		         System.out.println("Connecting to database..."); 
		    //     conn = DriverManager.getConnection(DB_URL,USER,PASS);
		         DriverManager.getConnection("jdbc:h2:tcp://localhost/mem:local;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE", "sa", "h2@123456"); 
		       /*  stmt = conn.createStatement();
		         System.out.println("we are in h2");
		         ResultSet rs = stmt.executeQuery("select * from User");
		         while(rs.next())
		         {
		        	 System.out.println(rs.getString(1)+" "+rs.getString(2));
		         }*/
		         System.out.println("Creating table in given database..."); 
		         stmt = conn.createStatement(); 
		         String sql =  "CREATE TABLE   REGISTRATION2 " + 
		            "(id INTEGER not NULL, " + 
		            " first VARCHAR(255), " +  
		            " last VARCHAR(255), " +  
		            " age INTEGER, " +  
		            " PRIMARY KEY ( id ))";  
		         stmt.executeUpdate(sql);
		         System.out.println("Created table in given database..."); 
		         
		         // STEP 4: Clean-up environment 
		         stmt.close(); 
		         conn.close(); 
		      }
		      catch(ClassNotFoundException cnfe)
		      {
		    	  cnfe.printStackTrace();
		      }catch(SQLException sqe)
		      {
		    	  sqe.printStackTrace();
		      }


	}

}
