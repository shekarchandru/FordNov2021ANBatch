package com.ford.nov11.noon;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSample {
    Queue <Customer> customerQueue;
    boolean flag;
    /*
       customerStack.push(new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1"));
        customerStack.push(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        customerStack.push(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        customerStack.push(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        customerStack.push(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));

     */
    public QueueSample() {
        flag = false;
        customerQueue = new PriorityQueue<Customer>();
        customerQueue.add(new Customer("C001", "Ramesh", "RTNagar", "9849999498", 1000.0f, "Product1"));
        customerQueue.add(new Customer("C002", "Mahesh", "Jayanagar", "9849934498", 2000.0f, "Product2"));
        customerQueue.add(new Customer("C003", "Sumanth", "Vijayanagar", "9845699498", 3000.0f, "Product3"));
        customerQueue.add(new Customer("C004", "Kiran", "Malleswaram", "9849996798", 4000.0f, "Product4"));
        customerQueue.add(new Customer("C005", "Rakesh", "Vijayanagar", "9834999498", 5000.0f, "Product5"));
    }

    public boolean fetchQueueObjectsThruIterator()
    {
        Iterator <Customer> customerIter = customerQueue.iterator();
        try
        {
            while(customerIter.hasNext())
            {
                Customer customer  = customerIter.next();
                System.out.println("The Dequeued Element is "+customer);
            }
            flag = true;

        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
