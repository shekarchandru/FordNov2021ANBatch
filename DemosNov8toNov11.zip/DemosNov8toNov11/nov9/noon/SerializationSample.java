package com.ford.nov9.noon;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationSample {
    ObjectOutputStream opStream;
    boolean flag = false;
    File file1;
    Employee[] myEmployees;
    public boolean serializeEmployeeObject()
    {
        /* for(int i=0;i<myEmployees.length;i++)
        {
            myEmployees[i] = new Employee();
        }*/
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch04-01Nov2021AN\\Files\\employees.txt");
        myEmployees = new Employee[4];

        myEmployees[0] = new Employee("E001","Kiran Kumar","RTNagar","9859959595",10000);
        myEmployees[1] = new Employee("E002","Kishan Kumar","Jayanagar","9859769595",11000);
        myEmployees[2] = new Employee("E003","Mohan Kumar","Vijayanagar","9859959875",12000);
        myEmployees[3] = new Employee("E004","Mahesh","Malleswaram","9859959435",13000);
        try {
            opStream = new ObjectOutputStream(new FileOutputStream(file1));
            opStream.writeObject(myEmployees);
            opStream.flush();
            opStream.close();
            System.out.println("Serialized Employee Objects successfully..");
            flag = true;
        } catch (IOException e) {
            e.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
