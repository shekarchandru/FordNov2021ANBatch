package com.ford.nov8.noon;

import java.io.BufferedOutputStream;
import java.io.IOException;

public class BufferedOutputStreamOutSample {
    BufferedOutputStream bStream;
    boolean flag = false;
    String str = "This Content goes to Console..";
    byte[] myBytes = new byte[100];
    public boolean writeToConsoleThruBuffer()
    {
        bStream = new BufferedOutputStream(System.out);
        myBytes = str.getBytes();
        try {
            bStream.write(myBytes);
            bStream.flush();

            System.out.println("Successfully wrote  to Console..");
            bStream.close();

            flag = true;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
