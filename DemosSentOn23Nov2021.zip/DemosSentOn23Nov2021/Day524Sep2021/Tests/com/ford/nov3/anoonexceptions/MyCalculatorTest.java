package com.ford.nov3.anoonexceptions;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MyCalculatorTest {

    MyCalculator mCalci;
    @BeforeEach
    void setUp() {
        mCalci = new MyCalculator();
    }

    @AfterEach
    void tearDown() {
        mCalci = null;
    }

    @Test
    public void shouldReturnDividend()
    {
        //Given
        int expectedResult = 5;
        //When
        int actualResult = mCalci.calculateDividend(2000,400);
        //Then
        assertEquals(expectedResult,actualResult);
    }
    @Test()
    public void shouldThrowArithmeticException()
    {
        //Given
        int numerator = 100;
        int denominator = 0;

        assertThrows(ArithmeticException.class,()->mCalci.calculateDividend(numerator,denominator));
    }

    @Test
    public void shouldReturnValueByIndex()
    {
        //given
        int numbers[] = {10,20,30,40,50};
        int expectedResult = 50;
        //when
        int actualResult = mCalci.getElementByIndex(numbers,4);
        //Then
        assertEquals(expectedResult,actualResult);
    }

    @Test
    public void shouldThrowArrayIndexOutOfBoundsException()
    {
        //given
        int numbers[] = {10,20,30,40,50};
        int myIndex = 10;
        assertThrows(ArrayIndexOutOfBoundsException.class,() -> mCalci.getElementByIndex(numbers,myIndex));
    }


}