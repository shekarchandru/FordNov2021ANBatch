package com.ford.nov8.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BufferedOutputStreamOutSampleTest {

    BufferedOutputStreamOutSample boutStream;
    @BeforeEach
    void setUp() {
        boutStream = new BufferedOutputStreamOutSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldWriteToMonitorThruBuffer()
    {
       assertTrue(boutStream.writeToMonitor());
    }

}