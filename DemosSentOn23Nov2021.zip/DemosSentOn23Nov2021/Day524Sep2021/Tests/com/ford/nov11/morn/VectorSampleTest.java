package com.ford.nov11.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VectorSampleTest {

    VectorSample vSample;
    @BeforeEach
    void setUp() {
        vSample = new VectorSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldGetVectorElementsThruEnumeration()
    {
        assertTrue(vSample.fetchElementsFromVectorThruEnumeration());
    }
    @Test
    public void shouldGetVectorElementsThruIterator()
    {
        assertTrue(vSample.fetchElementsFromVectorThruIterator());
    }
    @Test
    public void shouldGetVectorElementsThruNewIterator()
    {
        assertTrue(vSample.fetchElementsFromVectorThruIteratorNew());
    }


}