package com.ford.nov10.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class ArrayListSampleTest {
    ArrayListSample alSample;
    ArrayList myList;
    @BeforeEach
    void setUp() {

        alSample = new ArrayListSample();
        myList = new ArrayList();
        Employee e1 = new Employee("E001","Harsha","RTNagar","9848848848",10000);
        myList.add(e1);
        myList.add(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        myList.add(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        myList.add(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        myList.add(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));

    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldPopulateArrayList()
    {
        assertTrue(alSample.populateArrayList());
    }
    @Test
    public void shouldFetchArrayList()
    {
        assertTrue(alSample.fetchArrayListElements());
    }
    @Test
    public void shouldFetchThruFastEnumeration()
    {
        assertTrue(alSample.fetchArrayListByForEach());
    }
    @Test
    public void shouldPopulateArrayListAgain()
    {
        //Given in setUp
        //when
        ArrayList actualList = alSample.newPopulateArrayList();
        //then
        assertEquals(myList,actualList);
    }


}