package com.ford2.setter.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerInjectorTest {

    CustomerInjector customerInjector;
    @BeforeEach
    void setUp() {
        customerInjector = new CustomerInjector();
    }

    @AfterEach
    void tearDown() {
        customerInjector = null;
    }

    @Test
    void shouldInjectnjectSetterBasedCustomer1() {
        assertTrue(customerInjector.injectSetterBasedCustomer1());
    }

    @Test
    void shouldInjectnjectSetterBasedCustomer2() {
        assertTrue(customerInjector.injectSetterBasedCustomer2());
    }
}