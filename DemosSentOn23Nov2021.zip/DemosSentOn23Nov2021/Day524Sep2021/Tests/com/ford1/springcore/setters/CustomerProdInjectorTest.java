package com.ford1.springcore.setters;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerProdInjectorTest {
    CustomerProdInjector customerProdInjector;
    @BeforeEach
    void setUp() {
        customerProdInjector = new CustomerProdInjector();
    }

    @AfterEach
    void tearDown() {
        customerProdInjector = null;
    }

    @Test
    void shouldInjectCustomer1NProducts1() {
        assertTrue(customerProdInjector.injectCustomer1NProducts1());
    }

    @Test
    void shouldInjectCustomer2NProducts2() {
        assertTrue(customerProdInjector.injectCustomer2NProducts2());
    }
}