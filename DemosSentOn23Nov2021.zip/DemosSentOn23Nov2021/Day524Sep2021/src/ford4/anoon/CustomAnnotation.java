package ford4.anoon;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Method;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD,ElementType.TYPE})
@interface MySampleAnnotation
{
    int price();
    String address();
    String city();
}

@MySampleAnnotation(price=2000,address = "RTNagar",city="Bangalore")
class MyClass
{

}

public class CustomAnnotation {

    @MySampleAnnotation(price=2000,address = "RTNagar",city="Bangalore")
    public void display()
    {
        System.out.println("Displaying for Annotation Based Methods");
    }


    public static void main(String[] args) {
        CustomAnnotation customAnnotation = new CustomAnnotation();

        try {
            Method method = customAnnotation.getClass().getMethod("display");
            MySampleAnnotation mySampleAnnotation = method.getAnnotation(MySampleAnnotation.class);
            System.out.println(mySampleAnnotation.price());
            System.out.println(mySampleAnnotation.address());
            System.out.println(mySampleAnnotation.city());
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }

    }
}
