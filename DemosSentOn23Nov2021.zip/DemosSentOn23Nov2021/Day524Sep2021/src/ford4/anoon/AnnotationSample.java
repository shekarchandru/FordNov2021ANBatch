package ford4.anoon;

import java.util.Date;

public class AnnotationSample extends BaseClass {
//Date
//1900 January 01
    @Override
    @SuppressWarnings("unchecked")
    @Deprecated
    public void display() {
        int var1=10;
        super.display();
        System.out.println("Displaying Derived Class...");
        Date d1 = new Date();
        System.out.println("The Date is "+d1.getDate());
        System.out.println("The Month is "+d1.getMonth());
        System.out.println("the Year is "+d1.getYear());
    }

    public static void main(String[] args) {
        AnnotationSample annotationSample = new AnnotationSample();
        annotationSample.display();
    }
}
