package comford.nov02.interfaces;

public interface Banking {

    // Variables can initialized but it is static final
    int amount = 100;
    static final int num2 = 200;
    // Instance variables are not allowed
    public void createAccount();
    public void closeAccount();

}
