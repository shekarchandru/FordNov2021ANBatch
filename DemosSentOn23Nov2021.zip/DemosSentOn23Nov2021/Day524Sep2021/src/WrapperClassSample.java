public class WrapperClassSample {

    public void boxUnBox()
    {
        int x = 100;
        Object o = x; //BOXING
        System.out.println("the Value type wrapped in Object "+o);

        //UNBOXING
        int y = (int)o;
        System.out.println("the Ref type held in value type "+y);
    }

    public void wrapDataUsingWrapper()
    {
        int iVar = 2000;
        Integer iInteger = new Integer(iVar);//
        System.out.println("the int value in Integer Object "+iInteger);

        String strSalary = "2000";
        int iSalary = Integer.parseInt(strSalary);
        System.out.println("String salary parsed into int "+iSalary);

        String strSalary1 = "234.56";
        float fSalary = Float.parseFloat(strSalary1);
        System.out.println("String salary into float "+fSalary);

        String strSalary2 = "356363.44";
        double dblSalary = Double.parseDouble(strSalary2);
        System.out.println("String salary into Double "+dblSalary);

        double dblScore = 234333.45d;
        String strScore = Double.toString(dblScore);
        System.out.println("The score in Double "+dblScore);
        System.out.println("the double score in String "+strScore);

        float flScore = 234.56f;
        String strScoreFlt = Float.toString(flScore);
        System.out.println("The Score in float "+flScore);
        System.out.println("the float score in String "+strScoreFlt);

        Double dbl1 = new Double("233434.56");


        Integer int1 = new Integer("20000");
        Float fl1 = new Float("234.56");
        System.out.println("String to Double "+dbl1);
        System.out.println("String to Integer "+int1);
        System.out.println("String to Float "+fl1);

       /* "2000"
                int x = Integer.parseInt("2000")*/


    }

    public static void main(String[] args) {
        WrapperClassSample wcs = new WrapperClassSample();
       // wcs.boxUnBox();
        wcs.wrapDataUsingWrapper();
    }
}
