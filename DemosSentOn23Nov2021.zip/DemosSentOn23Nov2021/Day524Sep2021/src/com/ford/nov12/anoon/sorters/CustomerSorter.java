package com.ford.nov12.anoon.sorters;



import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class CustomerSorter {
    ArrayList<Customer> customers;
    public CustomerSorter()
    {
        customers = new ArrayList<Customer>();
        customers.add(new Customer("C005","Rakesh","Ernakulam","9834999498",5000.0f,"Product5"));
        customers.add(new Customer("C003","Sumanth","Hyderabad","9845699498",3000.0f,"Product3"));

        Customer c1 = new Customer("C001","Ramesh","Chennai","9849999498",1000.0f,"Product1");
        customers.add(c1);
        customers.add(new Customer("C004","Kiran","Faridabad","9849996798",4000.0f,"Product4"));

        customers.add(new Customer("C002","Mahesh","Bangalore","9849934498",2000.0f,"Product2"));

    }
    public ArrayList <Customer> sortCustomersById()
    {
        Collections.sort(customers,new IDSorter());
        System.out.println("Customers Sorted By Id using Comparator...");
        Iterator <Customer> idSortIter = customers.iterator();
        while(idSortIter.hasNext())
        {
            Customer customer = idSortIter.next();
            System.out.println(customer);
        }
        return customers;
    }
    public ArrayList <Customer> sortCustomersByName()
    {
        Collections.sort(customers,new NameSorter());
        System.out.println("Customers Sorted By Name using Comparator...");
        Iterator <Customer> nameSortIter = customers.iterator();
        while(nameSortIter.hasNext())
        {
            Customer customer = nameSortIter.next();
            System.out.println(customer);
        }
        return customers;
    }
    public ArrayList <Customer> sortCustomersByPurchValue()
    {
        Collections.sort(customers,new PurchaseValueSorter());
        System.out.println("Customers Sorted By Purchase Value using Comparator...");
        Iterator <Customer> purchValSortIter = customers.iterator();
        while(purchValSortIter.hasNext())
        {
            Customer customer = purchValSortIter.next();
            System.out.println(customer);
        }
        return customers;
    }

}


