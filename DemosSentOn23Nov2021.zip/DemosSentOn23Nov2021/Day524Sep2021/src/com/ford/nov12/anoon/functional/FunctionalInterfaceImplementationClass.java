package com.ford.nov12.anoon.functional;

public class FunctionalInterfaceImplementationClass {

    public static void main(String[] args) {

        //Implementation of Functional Interface method using Lambda Expression
        System.out.println("----------------MyInterface1-------------------");
        MyInterface1 inter1 = () -> {
            System.out.println("Welcome to Functional Interfaces...");
        };
        //Invocation of the FunctionalInterface Method
        inter1.display();
        System.out.println("----------------MyInterface2-------------------");
        MyInterface2 inter2 = (int x,int y) -> {
            int result = x + y;
            System.out.println("The Result is "+result);
        };
        System.out.println("----------------Customer-------------------");
        inter2.calculate(1000,2000);

        Customer customer1 = (int q,int p) ->{
            int result = q * p;
            if(result > 1000)
            {
                System.out.println("Invoice Amount is "+result);
                System.out.println("Invoice AMount is Eligible for Discount..");
            }
            else
            {
                System.out.println("Invoice Amount is "+result);
                System.out.println("Sorry, Invoice AMount Not eligible for Discount");
            }
        };
        customer1.calculateInvoiceAmt(400,10);
        customer1.calculateInvoiceAmt(80,10);
        System.out.println("----------------New Customer-------------------");

        NewCustomer ncustomer1 = (int quantity,int price) ->
        {
            int invoiceAmt = quantity * price;
            double finalInvoiceAmt = invoiceAmt - (0.1 * invoiceAmt);
            return finalInvoiceAmt;
        };

        NewCustomer ncustomer2 = (int quantity,int price) ->
        {
            int invoiceAmt = quantity * price;
            double finalInvoiceAmt = invoiceAmt - (0.2 * invoiceAmt);
            return finalInvoiceAmt;
        };
        System.out.println("---------------SalesData-------------------");

        SalesData sData = (int qty,int price,NewCustomer c) -> {
            int invoiceAmt =  qty * price;
            System.out.println("The Actual Invoice AMount is "+invoiceAmt);
            double discountedInvAmt = c.calculateInvoiceAmt(qty,price);
            System.out.println("The Discounted Invoice AMt is "+discountedInvAmt);

        };
        System.out.println("Invoice Details for Customer1");
        sData.processOrder(100,250,ncustomer1);
        System.out.println("---------------------");
        System.out.println("Invoice Details for Customer2");
        sData.processOrder(100,250,ncustomer2);

    }
}
