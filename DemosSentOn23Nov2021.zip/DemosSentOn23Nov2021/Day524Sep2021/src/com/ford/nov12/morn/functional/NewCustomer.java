package com.ford.nov12.morn.functional;

public interface NewCustomer {
    public double calculateInvoice(int qty,int price);
}
