package com.ford.nov8.noon;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class SampleFileReader {
    FileReader fReader;
    File file1;
    boolean flag = false;
    public boolean readFromCharFile()
    {
        String pathName = "C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch04-01Nov2021AN\\Files\\Supplier.txt";
        file1 = new File(pathName);
        int myChar;
        try {
            fReader = new FileReader(file1);
            while((myChar = fReader.read()) != -1)
            {
                System.out.print((char)myChar);
            }
            flag = true;
        }
        catch(FileNotFoundException fnfe)
        {
            fnfe.printStackTrace();
            flag = false;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
