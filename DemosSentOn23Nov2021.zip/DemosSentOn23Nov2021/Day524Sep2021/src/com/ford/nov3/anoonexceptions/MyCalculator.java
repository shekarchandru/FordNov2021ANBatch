package com.ford.nov3.anoonexceptions;

public class MyCalculator {

    public int getElementByIndex(int[] numbers,int nIndex)
    {
        //Arrays.toString(number)
        int result = 0;
        try {
            for (int i = 0; i < 5; i++) {
                System.out.println(numbers[i]);
            }
            result = numbers[nIndex];
            System.out.println("The Value of the Array in Index :" + nIndex + " is  :" + result);
        }
        catch(ArrayIndexOutOfBoundsException ae)
        {
            ae.printStackTrace();
            throw ae;
        }
        return result;
    }
    public int calculateDividend(int numerator,int denominator)
    {
        int result =0;
        System.out.println("We are about to Perform Division...");
        try {
            result = numerator / denominator;
        }
        catch(ArithmeticException ae)
        {
            ae.printStackTrace();
            throw ae;
          //  System.out.println(ae.getMessage());
        }
        System.out.println("The Result is "+result);
        System.out.println("We finished division...");
        return result;
    }

    public static void main(String[] args) {
        MyCalculator calci = new MyCalculator();
        System.out.println("We are about to call divider function....");
      /* try { */
            System.out.println(calci.calculateDividend(2000, 200));
            System.out.println(calci.calculateDividend(2000, 500));
            System.out.println(calci.calculateDividend(2000, 0));
            System.out.println(calci.calculateDividend(2000, 100));
            System.out.println(calci.calculateDividend(2000, 250));
       /* }
        catch(ArithmeticException ae)
        {
            ae.printStackTrace();
        }*/
        System.out.println("We finished calling divider function....");


    }
}
