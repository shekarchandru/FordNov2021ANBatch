package com.ford.collections;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

    LinkedList employees;

    public LinkedListSample()
    {
        employees = new LinkedList();
    }
    public void populateLinkedList()
    {
        employees.add(new Employee("E001","Harsha","RTNagar","9829929922",2345.56f));
        employees.add(new Employee("E002","Keerthana","Vijayanagar","9829934522",4345.56f));
        employees.add(new Employee("E003","Ramesh Kumar","Jayanagar","9845629922",3345.56f));
        employees.add(new Employee("E004","Vijayan","RTNagar","9829925672",1345.56f));
        employees.add(new Employee("E005","Roopesh","Malleswaram","9878929922",5345.56f));

    }
    public boolean fetchLinkedListObjects()
    {
        populateLinkedList();
        boolean flag = false;
        if(employees.isEmpty() == false)
        {
            Iterator empIter = employees.iterator();
            while(empIter.hasNext())
            {
                Employee e = (Employee)empIter.next();
                System.out.println(e);
            }
            flag = true;
        }
        employees.addFirst(new Employee("E006","Kiran","Malleswaram","9876479922",6345.56f));
        employees.addLast(new Employee("E007","Kishan","Koramangala","9875679922",5345.56f));
        System.out.println("-----------after adding front and back-----------");
        if(employees.isEmpty() == false)
        {
            Iterator empIter = employees.iterator();
            while(empIter.hasNext())
            {
                Employee e = (Employee)empIter.next();
                System.out.println(e);
            }
            flag = true;
        }
        System.out.println("-------------Employees in Descending Order-----------------");
        if(employees.isEmpty() == false)
        {
            Iterator descEmpIter = employees.descendingIterator();
            while(descEmpIter.hasNext())
            {
                Employee e = (Employee)descEmpIter.next();
                System.out.println(e);
            }
            flag = true;
        }
        return flag;
    }


}
