package com.ford.sep27;

public class JsonParser extends Parser{

    @Override
    public void parseFile(String fileType) {
        System.out.println("Parsed the File of TYpe "+fileType);
    }
}
