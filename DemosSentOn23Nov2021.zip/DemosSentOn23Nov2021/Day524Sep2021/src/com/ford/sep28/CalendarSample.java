package com.ford.sep28;

import java.util.Calendar;
import java.util.Date;

public class CalendarSample {

    public void manipulateDates()
    {
        Date myDate = new Date();
        System.out.println("The Time elapsed since 1900 is "+myDate.getTime());

        System.out.println("The Date is "+myDate.getDate());
        System.out.println("The Month is "+myDate.getMonth());
        System.out.println("The Day is "+myDate.getDay());
        System.out.println("the Year is "+(myDate.getYear()+1900));
        System.out.println("----------------------------");
        String month[] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        String day[] ={"Sat","Sun","Mon","Tue","Wed","Thu","Fri"};
            Calendar calendar  = Calendar.getInstance();
        System.out.println("The Actual Data representing the following elements");
        System.out.println("The Day Of Month is "+calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println("The Day Of Week  is "+calendar.get(Calendar.DAY_OF_WEEK));
        System.out.println("The Day Of Month is "+calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println("The Day Of Week  is "+day[calendar.get(Calendar.DAY_OF_WEEK)]);
        System.out.println("the Month is "+month[calendar.get(Calendar.MONTH)]);
        System.out.println("The Date is "+calendar.get(Calendar.DATE));
        System.out.println("The Year is "+calendar.get(Calendar.YEAR));
        System.out.println("The Week Of the MOnth  "+calendar.get(Calendar.WEEK_OF_MONTH));
        System.out.println("------------ACTUAL CALENDAR DATA is------------");



    }

    public static void main(String[] args) {
        CalendarSample cs = new CalendarSample();
        cs.manipulateDates();
    }

}
