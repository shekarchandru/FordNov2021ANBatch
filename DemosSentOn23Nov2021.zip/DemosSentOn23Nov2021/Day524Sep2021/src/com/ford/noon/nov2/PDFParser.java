package com.ford.noon.nov2;

public class PDFParser extends Parser{

    @Override
    public void parseFile(String fileType) {

        System.out.println("Completed Parsing of File "+fileType);
    }
}
