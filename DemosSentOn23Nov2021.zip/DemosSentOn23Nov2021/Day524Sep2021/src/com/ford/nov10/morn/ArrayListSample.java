package com.ford.nov10.morn;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {
    ArrayList employees;
    boolean flag ;

    public ArrayListSample() {
        employees = new ArrayList();
        flag = false;
    }

    public boolean populateArrayList()
    {
        Employee e1 = new Employee("E001","Harsha","RTNagar","9848848848",10000);
        employees.add(e1);
        employees.add(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employees.add(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employees.add(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employees.add(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));
      /*  System.out.println("Populated ArrayList successfully..");
        System.out.println("Initial Size is :"+employees.size());
        employees.add(3,new Employee("E006","Sumanth","KRPuram","7838388838",15000));
        System.out.println(employees);
        System.out.println("Latest Size is :"+employees.size());
        System.out.println("The element at 5 "+employees.get(5));
        employees.remove(2);
        System.out.println(employees);*/

        flag = true;
        return flag;
    }
    public ArrayList newPopulateArrayList()
    {
        Employee e1 = new Employee("E001","Harsha","RTNagar","9848848848",10000);
        employees.add(e1);
        employees.add(new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        employees.add(new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        employees.add(new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        employees.add(new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));
        return employees;
    }

    public boolean fetchArrayListElements()
    {
        populateArrayList();
        Iterator empIter = employees.iterator();
        System.out.println(" ArrayList Objects are..");
        while(empIter.hasNext())
        {
            Employee emp = (Employee)empIter.next();
            System.out.println(emp);
        }
        flag = true;
        return flag;
    }
    public boolean fetchArrayListByForEach()
    {
        populateArrayList();
       /* for(Object o:employees)
        {
            System.out.println(o);
        }*/
        System.out.println(employees);
        flag = true;
        return flag;
    }

}
