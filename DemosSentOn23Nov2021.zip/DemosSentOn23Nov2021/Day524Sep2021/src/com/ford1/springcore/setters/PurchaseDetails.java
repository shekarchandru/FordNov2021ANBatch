package com.ford1.springcore.setters;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class PurchaseDetails {
    String counterId;
    String salesMan;
    Map <CustomerNew,Product> purchases;

    public PurchaseDetails() {
    }

    public String getCounterId() {
        return counterId;
    }

    public void setCounterId(String counterId) {
        this.counterId = counterId;
    }

    public String getSalesMan() {
        return salesMan;
    }

    public void setSalesMan(String salesMan) {
        this.salesMan = salesMan;
    }

    public Map<CustomerNew, Product> getPurchases() {
        return purchases;
    }

    public void setPurchases(Map<CustomerNew, Product> purchases) {
        this.purchases = purchases;
    }

    public void displayPurchaseDetails()
    {

        System.out.println("The Purchase Made at the Counter "+counterId);
        System.out.println("And Sale Carried out by the Sales Person :"+salesMan);
        System.out.println("And The Purchase Details are....");
        Set <CustomerNew> customerKeySet = purchases.keySet();
        Iterator <CustomerNew> customerKeyIter = customerKeySet.iterator();
        while(customerKeyIter.hasNext())
        {
            CustomerNew customer = customerKeyIter.next();
            System.out.println("The Customer "+customer+" Purchased the  Product "+purchases.get(customer));
        }


    }
}
