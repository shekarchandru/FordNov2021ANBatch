package com.ford1.springcore.setters;

import java.util.Iterator;
import java.util.List;

public class Customer {
    private String customerId;
    private String customerName;
    private float purchaseValue;
    private List <Product> products;

    public Customer() {
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public float getPurchaseValue() {
        return purchaseValue;
    }

    public void setPurchaseValue(float purchaseValue) {
        this.purchaseValue = purchaseValue;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
    public void displayCustomerDetails()
    {
        System.out.println("Customer Details are ...");
        System.out.println("Customer Id is :"+customerId);
        System.out.println("Customer Name is :"+customerName);
        System.out.println("Customer purchased Goods worth "+purchaseValue);
        System.out.println("Customer Purchased the following Products ....");
        //System.out.println(products);
        Iterator <Product> prodIter = products.iterator();
        while(prodIter.hasNext())
        {
            Product product = prodIter.next();
            System.out.println(product);
        }
    }
}
