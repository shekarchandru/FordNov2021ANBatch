package com.ford1.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StudentInjector {
    public boolean injectStudent1()
    {
        boolean flag = false;
        try
        {
            ApplicationContext ctx = new ClassPathXmlApplicationContext("contextfiles/ApplicationContext1.xml");
            Student student1 = ctx.getBean("stud1",Student.class);
            student1.displayStudentDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
