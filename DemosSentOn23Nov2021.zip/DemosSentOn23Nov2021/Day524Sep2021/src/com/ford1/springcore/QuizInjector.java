package com.ford1.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuizInjector {

    ApplicationContext context;
    boolean flag = false;

    public boolean injectQuiz1()
    {
        try {
            context = new ClassPathXmlApplicationContext("contextfiles/QuizContext.xml");
            Quiz quiz = (Quiz) context.getBean("quiz1");
            quiz.displayQuizDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectQuiz2()
    {
        try {
            context = new ClassPathXmlApplicationContext("contextfiles/QuizContext.xml");
            Quiz quiz = (Quiz) context.getBean("quiz2");
            quiz.displayQuizDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
