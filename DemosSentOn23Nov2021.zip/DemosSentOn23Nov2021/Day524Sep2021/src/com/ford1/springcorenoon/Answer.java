package com.ford1.springcorenoon;

public class Answer {
    String answerId;
    String answer;

    public Answer() {
    }

    public Answer(String answerId, String answer) {
        this.answerId = answerId;
        this.answer = answer;
    }

    @Override
    public String toString() {
        return "Answer{" +
                "answerId='" + answerId + '\'' +
                ", answer='" + answer + '\'' +
                '}';
    }
}
