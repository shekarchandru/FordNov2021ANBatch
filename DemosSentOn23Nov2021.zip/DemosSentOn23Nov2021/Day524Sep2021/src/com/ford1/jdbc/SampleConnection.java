package com.ford1.jdbc;

import java.sql.*;

public class SampleConnection {
    public static void main(String[] args) {

        Connection con;
        Statement stmt;
        ResultSet rs;
        String url = "jdbc:mysql://localhost:3306/booksdb";
        String user="root";
        String password = "MySQL_@123456";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url,user,password);
            stmt = con.createStatement();
            rs = stmt.executeQuery("select * from book");
            while(rs.next())
            {
                System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4));
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }
    }
}
