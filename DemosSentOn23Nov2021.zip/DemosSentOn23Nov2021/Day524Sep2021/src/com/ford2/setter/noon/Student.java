package com.ford2.setter.noon;


import java.util.Iterator;
import java.util.List;

public class Student {

    String studentId;
    String studentName;
    String studentPhone;
    List <Subject> subjects;


    public Student() {
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentPhone() {
        return studentPhone;
    }

    public void setStudentPhone(String studentPhone) {
        this.studentPhone = studentPhone;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }
    public void displayStudentDetails()
    {
        System.out.println("Student Details are ..");
        System.out.println("Student Id :"+studentId);
        System.out.println("Student Name :"+studentName);
        System.out.println("Student Phone :"+studentPhone);
        System.out.println("The Subjects Taken up the student are...");
        Iterator <Subject> subjIter = subjects.iterator();
        while(subjIter.hasNext())
        {
            Subject subject = subjIter.next();
            System.out.println(subject);
        }
    }
}
