package com.cts.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.beans.EmployeeBean;

public class TestBean1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context2 = new ClassPathXmlApplicationContext("applicationContext.xml");
	/*	System.out.println("--------------------ID--------------------");
		EmployeeBean emp3 = context2.getBean("emp3", EmployeeBean.class);
		emp3.displayId();
		System.out.println("--------------------ID & Name---------------------");
		EmployeeBean emp4 = context2.getBean("emp4", EmployeeBean.class);
		emp4.displayIdName();
		System.out.println("--------------------ID,Name & Salary---------------------");
		EmployeeBean emp5 = context2.getBean("emp5", EmployeeBean.class);
		emp5.displayIdNameSalary();*/
		
		EmployeeBean eb1 = context2.getBean("emp6", EmployeeBean.class);
		eb1.displayEmployeeDetails();
		System.out.println("--------------------------");
		EmployeeBean eb2 = context2.getBean("emp7", EmployeeBean.class);
		eb2.displayEmployeeDetails();
		
		
		
		
	}

}
