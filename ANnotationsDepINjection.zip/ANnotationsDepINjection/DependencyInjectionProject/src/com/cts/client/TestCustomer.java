package com.cts.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cts.beans.Customer;

public class TestCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext1.xml");
		Customer customer1 = context.getBean("cust1", Customer.class);
		System.out.println("Customer1 details are--------------");
		customer1.displayCustomer();
		System.out.println("Customer2 details are--------------");
		Customer customer2 = context.getBean("cust2", Customer.class);
		customer2.displayCustomer();
		
		
	}

}
