package com.cts.beans;

import java.util.Iterator;
import java.util.List;

public class Customer {

	String custId;
	String custName;
	String purchaseValue;
	List <String> products;
	
	public Customer() {
		super();
	}
	
	public Customer(String custId, String custName, String purchaseValue, List<String> products) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.purchaseValue = purchaseValue;
		this.products = products;
	}

	public void displayCustomer()
	{
		System.out.println("The Customer Details are ...");
		System.out.println("Customer Id "+this.custId);
		System.out.println("Customer Name "+this.custName);
		System.out.println("Purchase Value "+this.purchaseValue);
		System.out.println("the Products Purchased Are");
		Iterator <String> listIter = products.iterator();
		while(listIter.hasNext())
		{
			String product = listIter.next();
			System.out.println(product);
		}
		
	}
	
	
}
