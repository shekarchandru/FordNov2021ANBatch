package com.cts.beans;

import java.util.List;

public class Answer {

		String ansId;
		String ansBy;
		List <String> answer;
		
		public Answer() {
			super();
		}

		public Answer(String ansId, String ansBy, List<String> answer) {
			super();
			this.ansId = ansId;
			this.ansBy = ansBy;
			this.answer = answer;
		}

		@Override
		public String toString() {
			return "Answer [ansId=" + ansId + ", ansBy=" + ansBy + ", answer=" + answer + "]";
		}
		
		
		
		
}
