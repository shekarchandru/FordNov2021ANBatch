package com.cts.beans;

public class EmployeeBean {

	String empId;
	String empName;
	int empSalary;
	
	Address empAddress;
	
	public EmployeeBean() {
		super();
	}

	
	public EmployeeBean(String empId) {
		super();
		this.empId = empId;
	}

	

	public EmployeeBean(String empId, String empName, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
	}


	public EmployeeBean(String empId, String empName) {
		super();
		this.empId = empId;
		this.empName = empName;
	}

	

	public EmployeeBean(String empId, String empName, int empSalary, Address empAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empAddress = empAddress;
	}


	public String welcome()
	{
		return "Welcome to Spring Core";
	}
	public void getMessage()
	{
		System.out.println("Welcome to Beans..");
	}
	public void displayId()
	{
		System.out.println("Employee Id is "+this.empId);
	}
	public void displayIdName()
	{
		System.out.println("Employee Id is "+this.empId);
		System.out.println("Employee Name is "+this.empName);
	}
	public void displayIdNameSalary()
	{
		System.out.println("Employee Id is "+this.empId);
		System.out.println("Employee Name is "+this.empName);
		System.out.println("Employee Salary is "+this.empSalary);
	}
	public void displayEmployeeDetails()
	{
		System.out.println("Employee Id is "+this.empId);
		System.out.println("Employee Name is "+this.empName);
		System.out.println("Employee Salary is "+this.empSalary);
		System.out.println("Address Details are ..");
		System.out.println(this.empAddress);
	}
}
