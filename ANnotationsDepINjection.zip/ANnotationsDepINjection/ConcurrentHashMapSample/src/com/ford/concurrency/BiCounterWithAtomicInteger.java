package com.ford.concurrency;

import java.util.concurrent.atomic.AtomicInteger;

public class BiCounterWithAtomicInteger {

	private AtomicInteger i = new AtomicInteger();
	private AtomicInteger j = new AtomicInteger();
	
	
	public int getI() {
		return i.get();
	}

	public void setJ(AtomicInteger j) {
		this.j = j;
	}
	public int getJ() {
		return j.get();
	}

	public void setI(AtomicInteger i) {
		this.i = i;
	}
	
	/*synchronized*/ public void incrementI()
	{
		i.incrementAndGet();
		//get i
		//increment
		//set i
		// when multiple thread access
		// this increment function
	}
	/*synchronized*/ public void incrementJ()
	{
		j.incrementAndGet();
		//get i
		//increment
		//set i
		// when multiple thread access
		// this increment function
	}
}
