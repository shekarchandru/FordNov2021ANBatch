package com.ford.annotationscolls;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean
	public CollectionsBean getCollectionsBean()
	{
		return new CollectionsBean();
	}
	
	@Bean
	public List <String> countries()
	{
		return Arrays.asList("India","USA","Australia","Japan","Canada");
	}
	
	@Bean
	public Map <String,String> countryPopulation()
	{
		Map <String,String> countryPop = new HashMap<String,String>();
		countryPop.put("USA", "30C");
		countryPop.put("India", "130C");
		countryPop.put("China", "140C");
		countryPop.put("England", "6C");
		countryPop.put("Canada", "4C");
		return countryPop;
		
	}
}
