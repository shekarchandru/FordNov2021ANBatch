package com.ford.annotationscolls;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

public class CollectionsBean {
	
	@Autowired
	List <String> countries = new ArrayList();
	
	@Autowired
	Map <String,String> countryPopulation = new HashMap<String,String>();
	
	List <String> getCountryDetails()
	{
		return getCountries();
	}
	Map <String,String> getCountryPopulationDetails()
	{
		return getCountryPopulations();
	}
	private List <String> getCountries()
	{
		return countries;
	}
	private Map <String,String> getCountryPopulations()
	{
		return countryPopulation;
	}

}
