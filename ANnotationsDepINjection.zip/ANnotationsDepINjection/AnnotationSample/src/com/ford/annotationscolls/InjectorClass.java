package com.ford.annotationscolls;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class InjectorClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		CollectionsBean collectionsBean = context.getBean(CollectionsBean.class);
		System.out.println(collectionsBean.getCountryDetails());
		System.out.println(collectionsBean.getCountryPopulationDetails());
	}

}
