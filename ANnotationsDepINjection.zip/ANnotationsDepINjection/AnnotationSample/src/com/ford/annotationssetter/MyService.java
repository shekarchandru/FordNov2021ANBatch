package com.ford.annotationssetter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MyService {
	
	private DaoClass daoClass;
	
	@Autowired
	public MyService()
	{
		
	}
	public DaoClass getDaoClass() {
		return daoClass;
	}

	@Autowired
	public void setDaoClass(DaoClass daoClass) {
		this.daoClass = daoClass;
	}/**/

	public List <String> getCountriesData()
	{
		return this.daoClass.getCountries();
	}
	
	
	

}
