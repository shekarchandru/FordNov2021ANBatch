package com.ford.annotationssetter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class DaoClass {
	
	public DaoClass()
	{
		System.out.println("Constructor Invoked...");
	}
	
	List <String> getCountryDetails()
	{
		return getCountries();
	}
	public List <String> getCountries()
	{
		List <String> countries = new ArrayList();
		countries.add("India");
		countries.add("USA");
		countries.add("Australia");
		countries.add("Japan");
		countries.add("Canada");
		return countries;
	}

}
