package com.ford.annotationssetter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

	@Bean("controller1")
	public MyController getController()
	{
		return new MyController();
	}
	@Bean("myService")
	public MyService getService()
	{
		return new MyService();
	}
	@Bean("daoClass")
	public DaoClass getDaoClass()
	{
		return new DaoClass();
	}
	
	
}
