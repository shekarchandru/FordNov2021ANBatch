package com.ford.annotationssetter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller("controller1")
public class MyController {
	
	private MyService myservice;
	
	@Autowired
	public MyController()
	{
	}
	public MyService getMyservice() {
		return myservice;
	}

	@Autowired
	public void setMyservice(MyService myservice) {
		this.myservice = myservice;
	}
	
	public List <String> getCountries()
	{
		return myservice.getCountriesData();
	}

}
