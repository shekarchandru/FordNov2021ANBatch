package com.ford.annotationssetter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ford.annotationssetter.AppConfig;


public class SetterInjectorClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		MyController myController = (MyController)context.getBean("controller1");
		System.out.println(myController.getCountries());
	}

}
