package com.ford.annotationcons;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyService {

	 MyDao myDao;
	 
	 @Autowired
	 public MyService(MyDao myDao)
	 {
		 this.myDao = myDao;
	 }
	 
	 public List <String> getCountriesSvc()
	 {
		 return this.myDao.getCountryDetails();
	 }
}
