package com.ford.annotationcons;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ford.annotationcons.AppConfig;

public class InjectorClass {

	public static void main(String[] args)
	{
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		MyController myController = (MyController)context.getBean(MyController.class);
		System.out.println(myController.getCountriesC());
	}
}
