package com.ford.annotationcons;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



@Configuration
public class AppConfig {

	@Bean
	public MyController myController(MyService myService)
	{
		return new MyController(myService);
	}
	@Bean
	public MyService myService(MyDao myDao)
	{
		return new MyService(myDao);
	}
	@Bean
	public MyDao myDao()
	{
		return new MyDao();
	}
/*	@Bean
	public MyController getController(MyService myService)
	{
		return new MyController(myService);
	}
	@Bean("myService")
	public MyService getService(MyDao myDao)
	{
		return new MyService(myDao);
	}
	@Bean("myDao")
	public MyDao getDaoClass()
	{
		return new MyDao();
	}*/
}
