package com.ford.annotationcons;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ford.annotationcons.MyService;

@Component
public class MyController {

	private MyService myService;
	@Autowired
	public MyController()
	{
	
	}
	@Autowired
	public MyController(MyService myService)
	{
		this.myService = myService;
	}
	
	public List <String> getCountriesC()
	{
		return myService.getCountriesSvc();
	}
}
