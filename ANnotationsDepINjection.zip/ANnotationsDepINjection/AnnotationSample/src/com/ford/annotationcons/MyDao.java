package com.ford.annotationcons;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class MyDao {

	public MyDao()
	{
		
	}
	List <String> getCountryDetails()
	{
		return getCountries();
	}
	private List <String> getCountries()
	{
		List <String> countries = new ArrayList();
		countries.add("India");
		countries.add("USA");
		countries.add("Australia");
		countries.add("Japan");
		countries.add("Canada");
		return countries;
	}

}
