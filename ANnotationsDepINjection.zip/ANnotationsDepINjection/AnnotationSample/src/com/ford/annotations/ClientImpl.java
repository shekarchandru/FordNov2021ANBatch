package com.ford.annotations;

public class ClientImpl implements Client{

	Service service;
	public ClientImpl(Service service)
	{
		this.service = service;
	}
	@Override
	public void getClientInfo() {
		// TODO Auto-generated method stub
		System.out.println("Returning Client Info...");
		String string = service.getInfo();
		System.out.println("The Service Returned "+string);
		
	}

}
