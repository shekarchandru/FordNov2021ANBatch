package com.ford.annotations;

public class ServiceImpl implements Service{

	@Override
	public String getInfo() {
		// TODO Auto-generated method stub
		return "Returning service Details";
	}

}
