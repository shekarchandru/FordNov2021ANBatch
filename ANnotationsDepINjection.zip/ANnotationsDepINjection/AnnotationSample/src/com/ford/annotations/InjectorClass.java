package com.ford.annotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class InjectorClass {

	public static void main(String[] args)
	{
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Client client = (Client)context.getBean("client1");
		client.getClientInfo();
		
		Service service = (Service)context.getBean("service1");
		String info = service.getInfo();
		System.out.println(info);
	}
}
