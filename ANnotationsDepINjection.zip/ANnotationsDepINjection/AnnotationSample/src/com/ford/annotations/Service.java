package com.ford.annotations;

public interface Service {
	
	public String getInfo();

}
