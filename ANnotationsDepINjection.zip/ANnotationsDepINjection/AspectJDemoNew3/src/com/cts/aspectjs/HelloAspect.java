package com.cts.aspectjs;

public class HelloAspect {

	public static void sayHello()
	{
		System.out.println("Hello...");
	}
	public static void greeting()
	{
		sayHello();
		System.out.println("Archimedis...");
	}
	public static void main(String[] args) 
	{
		sayHello();
		System.out.println("-------------");
		greeting();
	}
}
