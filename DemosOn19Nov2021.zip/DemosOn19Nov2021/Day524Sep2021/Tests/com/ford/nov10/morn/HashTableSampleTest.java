package com.ford.nov10.morn;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HashTableSampleTest {

    HashTableSample htSample;
    Employee emp1 ;
    @BeforeEach
    void setUp() {
        htSample = new HashTableSample();
        emp1 = new Employee("E001","Harsha","RTNagar","9848848848",10000);

    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldReturnHashTableValues()
    {
        assertTrue(htSample.getHashTableData());
    }
    @Test
    public void shouldReturnEmployeeForKey()
    {
        //Given in Setup plus the following
        String empId = "E001";

        //When
        Employee  actualEmployee = htSample.getEmployeeByKey(empId);
        //Then
        assertEquals(emp1,actualEmployee);
    }

    @Test
    public void shouldReturnValuesOfHashTable()
    {
        assertTrue(htSample.getHashTableValues());
    }


}