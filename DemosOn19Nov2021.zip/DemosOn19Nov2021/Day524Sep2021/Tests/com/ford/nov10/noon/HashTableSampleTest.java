package com.ford.nov10.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HashTableSampleTest {

    HashTableSample htSample;
    Customer expectedCustomer;
    @BeforeEach
    void setUp() {
        expectedCustomer = new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2");
        htSample = new HashTableSample();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldDisplayValuesOfHashTable()
    {
        assertTrue(htSample.getHashTableValues());
    }
    @Test
    public void shouldDisplayValuesOfHashTableOnly()
    {
        assertTrue(htSample.getHashTableValuesOnly());
    }

    @Test
    public void shouldReturnCustomerByKey()
    {
        //Given along with SetUp;
        String custId = "C002";
        //When
        Customer actualCustomer = htSample.getCustomerByKeyFromHashTable(custId);
        //Then
        assertEquals(expectedCustomer,actualCustomer);
    }
}