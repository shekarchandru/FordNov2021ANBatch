package com.ford.sep27;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorNewTest {

    CalculatorNew cCal;
    @BeforeEach
    void setUp() {
        cCal = new CalculatorNew();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldThrowExceptionForDivideByZero()
    {
       /* */Exception exception  = assertThrows(ArithmeticException.class, () -> cCal.divideNum1ByNum2(20,0));

    }
    @Test
    public void shouldReturnDividend()
    {
        assertEquals(100,cCal.divideNum1ByNum2(500,5));
    }

}