package com.ford.sep28;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArrayExceptionClassTest {

    ArrayExceptionClass aec ;
    @BeforeEach
    void setUp() {
        aec = new ArrayExceptionClass();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldReturnElementOfArray()
    {
        //given
        int[] myArray = {10,20,30,40,50};
        //when
        int result = aec.getElementByIndex(myArray,4);
        //then
        assertEquals(50,result);
    }
    @Test
    public void shouldReturnElementOfArrayAgain()
    {
        //given
        String countries[] = {"India","United Kingdom","USA","Australia","Germany","Japan"};
        //when
        String country = aec.getCountryByIndex(countries,3);
        //then
        assertEquals("Australia",country);


    }
}