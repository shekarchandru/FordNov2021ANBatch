package comford.nov02.interfaces;

public class MyAccount implements CreditCard,DebitCard{
    @Override
    public void createAccount() {
        System.out.println("Account is Created .....");
    }

    @Override
    public void closeAccount() {
        System.out.println("Account is Closed .....");
    }

    @Override
    public void calculateOutstandingAmt() {
        System.out.println("Outstanding Amount is Calculated .....");

    }

    @Override
    public void calculateCCInterest() {
        System.out.println("Credit Card Interest is calculated .....");
    }

    @Override
    public void calculateRedemptionPoints() {

        System.out.println("Redemption Points are Calculated .....");
    }

    @Override
    public void calculateDCInterest() {

        System.out.println("Debit Card INterest is Calculated .....");
    }

    @Override
    public void checkBalance() {
        System.out.println(" Balance available is ...");
    }

    @Override
    public void withdrawAmount() {
        System.out.println("AMount withdrwan is " );
    }

    @Override
    public void createPolicy() {
        System.out.println("The Policy is Created.....");
    }

    @Override
    public void terminatePolicy() {
        System.out.println("The Policy is Terminated...");
    }

    @Override
    public void calculatePremium() {
        System.out.println("Premium is Calculated...");
    }

    public static void main(String[] args) {
        MyAccount mac = new MyAccount();
        mac.createAccount();

        mac.calculateCCInterest();
        mac.calculateOutstandingAmt();
        mac.calculateRedemptionPoints();

        mac.calculateDCInterest();
        mac.checkBalance();
        mac.withdrawAmount();


        mac.createPolicy();
        mac.calculatePremium();
        mac.terminatePolicy();

        mac.closeAccount();
    }
}
