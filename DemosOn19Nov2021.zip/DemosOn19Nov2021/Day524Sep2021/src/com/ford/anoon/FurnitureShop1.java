package com.ford.anoon;

public class FurnitureShop1 {
    public static void main(String[] args) {
      //  BookShelf shelf1 = new BookShelf(4,5,7,6);
        BookShelf shelf1 = new BookShelf();
       shelf1.acceptBookShelfDetails();
        shelf1.displayBookShelfDetails();
        System.out.println("-------------------------");
        Furniture furniture1 = new Furniture();
        furniture1.acceptFurnitureDetails();
        furniture1.displayFurnitureDetails();

    }
}
