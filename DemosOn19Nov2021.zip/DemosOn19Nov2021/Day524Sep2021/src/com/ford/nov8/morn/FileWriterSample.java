package com.ford.nov8.morn;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterSample {
    String str ="We are Writing into Char Stream";
    FileWriter fWriter;
    File file1;
    boolean flag = false;
    public boolean writeToCharStream()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\Supplier.txt");
        try {
            fWriter = new FileWriter(file1);
            fWriter.write(str);
            System.out.println("We wrote successfully into char Stream...");
            fWriter.flush();
            fWriter.close();
            flag = true;
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }


}
