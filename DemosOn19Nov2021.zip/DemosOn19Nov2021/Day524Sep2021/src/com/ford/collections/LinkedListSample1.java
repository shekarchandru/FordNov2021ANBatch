package com.ford.collections;

import java.util.ArrayList;
import java.util.Iterator;

public class LinkedListSample1 {
    public static void main(String[] args) {

        ArrayList countries = new ArrayList();
        countries.add("India");
        countries.add(new Integer(200));
        countries.add(300);
        countries.add(2345.55f);
        countries.add(true);

        Iterator countryIter = countries.iterator();
        while(countryIter.hasNext())
        {
           // String str = (String)countryIter.next()
            //Integer intr = (Integer)countryIter.next();
            System.out.println(countryIter.next());
        }

    }
}
