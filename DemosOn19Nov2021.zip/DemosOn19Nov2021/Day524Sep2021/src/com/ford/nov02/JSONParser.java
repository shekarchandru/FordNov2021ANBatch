package com.ford.nov02;

public class JSONParser extends Parser {
    @Override
    public void parseFile(String fileType) {
        System.out.println(" Parsing JSONFile "+fileType);
    }
    @Override
    public void method1() {

    }
}
