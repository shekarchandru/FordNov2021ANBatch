package com.ford.nov02;

public class DerivedFromFinalClass /*extends MyFinalClass*/{
}
