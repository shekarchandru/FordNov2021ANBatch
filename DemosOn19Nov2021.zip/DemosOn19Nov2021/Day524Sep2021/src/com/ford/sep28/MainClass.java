package com.ford.sep28;

public class MainClass {
    public static void main(String[] args) {

            MyFinalClass mfc = new MyFinalClass();
            mfc.calculate(100,200);
            mfc.displayBonus();

    }
}
