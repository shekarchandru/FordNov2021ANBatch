package com.ford.nov10.morn;

import java.util.ArrayList;
import java.util.Iterator;

public class GenericUnderstanding {

    public void displayList()
    {
        ArrayList <Employee> employees = new ArrayList<Employee>();

        ArrayList <String> myStrings = new ArrayList<String>();

        ArrayList aList = new ArrayList();
        int num1 = 200;
        aList.add(num1);// Boxing - value type to Reference
        //Integer numx = new Integer(num1)
        aList.add("Hello");
        aList.add(true);
        aList.add(1234.45);
        aList.add(new Employee("E001","Harsha","RTNagar","9848848848",10000));

        Iterator myIter = aList.iterator();

        while(myIter.hasNext())
        {
            Object o = myIter.next();
            System.out.println(o);
        }
    }

    public static void main(String[] args) {
        GenericUnderstanding genUnderstanding = new GenericUnderstanding();
        genUnderstanding.displayList();
    }
}
