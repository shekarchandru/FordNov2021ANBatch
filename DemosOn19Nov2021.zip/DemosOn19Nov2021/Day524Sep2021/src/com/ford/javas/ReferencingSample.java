package com.ford.javas;
interface Messageable{

    Message getMessage(String msg);
}
interface Messageable1 {
    void getMessage();
}
class Message{
    Message()
    {
        System.out.println("default constructor");
    }
    Message(String str){
        System.out.println(str);
    }
}

public class ReferencingSample {
    public static void main(String[] args) {
        Messageable hello =  Message::new;
        hello.getMessage("helo");

        Messageable1 hello1 =  Message::new;
        hello1.getMessage();
    }
}
