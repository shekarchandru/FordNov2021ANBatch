package com.ford.nov9.morn;

import java.io.*;

public class DataOutputStreamSample {

    DataOutputStream doStream;
    DataInputStream diStream;
    File file1;
    boolean flag = false;
    public boolean writeAndReadFromDataStream()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\StockBroker.txt");
       try {
           doStream = new DataOutputStream(new FileOutputStream(file1));
           doStream.writeFloat(1234.45f);
           doStream.writeBoolean(true);
           doStream.writeInt(45000);
           doStream.writeUTF("This is a String");
           doStream.writeDouble(1234.456);
           doStream.flush();
           doStream.close();
           flag = true;
       }
       catch(FileNotFoundException fnfe)
       {
           fnfe.printStackTrace();
           flag = false;
       }
       catch(IOException ioe)
       {
           ioe.printStackTrace();
           flag = false;
       }

        try {
            diStream = new DataInputStream(new FileInputStream(file1));
            System.out.println("The Float Data "+diStream.readFloat());
            System.out.println("The Boolean Data "+diStream.readBoolean());
            System.out.println("The Int Data "+diStream.readInt());
            System.out.println("The String Data "+diStream.readUTF());
            System.out.println("The Double Data "+diStream.readDouble());
            diStream.close();
            flag = true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            flag = false;
        } catch(IOException ioe)
        {
            ioe.printStackTrace();
        }

    return flag;
    }


}
