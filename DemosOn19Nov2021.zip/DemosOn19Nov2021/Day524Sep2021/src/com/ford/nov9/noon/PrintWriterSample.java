package com.ford.nov9.noon;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterSample {

    PrintWriter pw;
    File file1;
    boolean flag = false;
    public boolean writeThruPrintWriter()
    {
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch03-01Nov2021Morn\\Files\\PrinterFile.txt");
        try {
            pw = new PrintWriter(new FileWriter(file1));
            pw.print("EmployeeName \t");
            pw.print("Employee Address \t");
            pw.print("Employee Phone \t");
            pw.print("Employee Salary \t");
            pw.println();

            pw.print("Suman \t");
            pw.print("Viajayanagar \t");
            pw.print("9253439939 \t");
            pw.print("12000 \t");
            pw.println();

            pw.print("Kiran \t");
            pw.print("Koramangala \t");
            pw.print("9285369939 \t");
            pw.print("13000 \t");
            pw.println();

            pw.print("Vinay \t");
            pw.print("RJNagar \t");
            pw.print("9283939349 \t");
            pw.print("13000 \t");
            pw.println();
            pw.flush();
            pw.close();
            System.out.println("Wrote into PrintWriter..");
            flag = true;
        } catch (IOException e) {
            e.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
