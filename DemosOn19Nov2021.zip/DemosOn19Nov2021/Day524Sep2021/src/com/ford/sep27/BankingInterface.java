package com.ford.sep27;

public interface BankingInterface {
    public void createAccount();
    public void closeAccount();

}
