package com.ford.sep27;

public class XMLParser extends Parser {

    @Override
    public void parseFile(String fileType) {

        System.out.println("Parsed the File of Type "+fileType);
    }
}
