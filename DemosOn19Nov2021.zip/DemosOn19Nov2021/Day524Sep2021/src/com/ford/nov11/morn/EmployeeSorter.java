package com.ford.nov11.morn;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class EmployeeSorter {

    public static void main(String[] args) {
        ArrayList <Employee> employees = new ArrayList<Employee>();
        employees.add(new Employee("E002","Babu","Ahmedabad","9499499494",12000));
        employees.add(new Employee("E001","Amarnath","Faridabad","9499499494",10000));
        employees.add(new Employee("E003","Chandu","Coimbatore","9499499494",14000));
        Collections.sort(employees);
        Iterator <Employee> empIter = employees.iterator();
        System.out.println("Id Sorted Employees....");
        while(empIter.hasNext())
        {
            Employee employee = empIter.next();
            System.out.println(employee);
        }
    }
}
