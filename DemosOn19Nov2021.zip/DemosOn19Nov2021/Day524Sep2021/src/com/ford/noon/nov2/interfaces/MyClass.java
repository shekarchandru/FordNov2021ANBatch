package com.ford.noon.nov2.interfaces;

public class MyClass {

    public static void main(String[] args) {
        MyAccountNew mac = new MyAccountNew();
        mac.createAccount();

        mac.calculateCCInterest();
        mac.calculateOutStanding();
        mac.calculateRedemptionPoints();

        mac.checkBalance();
        mac.depositAmt();
        mac.withdrawAmt();

        mac.createPolicy();
        mac.calculatePremium();
        mac.terminatePolicy();

        mac.closeAccount();
    }
}
