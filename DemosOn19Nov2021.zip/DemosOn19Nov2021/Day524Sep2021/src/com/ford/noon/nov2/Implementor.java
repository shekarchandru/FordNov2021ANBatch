package com.ford.noon.nov2;

public class Implementor {


    public void callParser(Parser parser,String fileType)
    {
        parser.parseFile(fileType);
    }

}
