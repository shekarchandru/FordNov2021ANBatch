package com.ford1.springcorenoon;

import java.util.Iterator;
import java.util.List;

public class Question {
    String questionId;
    String question;
    List <Answer> answers;

    public Question() {
    }

    public Question(String questionId, String question, List<Answer> answers) {
        this.questionId = questionId;
        this.question = question;
        this.answers = answers;
    }
    public void displayQuestionAndAnswers()
    {
        System.out.println("The Question Details are ...");
        System.out.println("Question Id :"+questionId);
        System.out.println("Question is :"+question);
        System.out.println("And the Corresponding answers are :");
        Iterator <Answer> ansIter = answers.iterator();
        while(ansIter.hasNext())
        {
            Answer answer = ansIter.next();
            System.out.println(answer);
        }

    }
}
