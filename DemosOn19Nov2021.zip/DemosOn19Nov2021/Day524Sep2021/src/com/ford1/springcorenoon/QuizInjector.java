package com.ford1.springcorenoon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuizInjector {
    ApplicationContext context = new ClassPathXmlApplicationContext("QuizApplicationContext.xml");
    boolean flag = false;
    public  boolean injectQuiz1()
    {
        try
        {
            Quiz quiz1 = (Quiz)context.getBean("quiz1");
            quiz1.displayQuizDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public  boolean injectQuiz2()
    {
        try
        {
            Quiz quiz2 = (Quiz)context.getBean("quiz2");
            quiz2.displayQuizDetails();
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }

}
