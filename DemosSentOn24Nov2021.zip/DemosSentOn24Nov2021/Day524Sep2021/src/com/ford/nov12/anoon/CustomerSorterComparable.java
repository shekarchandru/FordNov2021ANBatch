package com.ford.nov12.anoon;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class CustomerSorterComparable {

    ArrayList <Customer> customers;
    public CustomerSorterComparable()
    {
        customers = new ArrayList<Customer>();
        customers.add(new Customer("C005","Rakesh","Ernakulam","9834999498",5000.0f,"Product5"));
        customers.add(new Customer("C003","Sumanth","Hyderabad","9845699498",3000.0f,"Product3"));

        Customer c1 = new Customer("C001","Ramesh","Chennai","9849999498",1000.0f,"Product1");
        customers.add(c1);
        customers.add(new Customer("C004","Kiran","Faridabad","9849996798",4000.0f,"Product4"));

        customers.add(new Customer("C002","Mahesh","Bangalore","9849934498",2000.0f,"Product2"));

    }
    public ArrayList<Customer> getCustomersSortedById()
    {
        Collections.sort(customers);
        Iterator <Customer> custIter = customers.iterator();
        System.out.println("Customers Sorted By Id.. are");
        while(custIter.hasNext())
        {
            Customer customer = custIter.next();
            System.out.println(customer);
        }
        return customers;
    }
    public ArrayList <Customer> getCustomersSortedByAddress()
    {
        Collections.sort(customers);
        Iterator <Customer> custIter = customers.iterator();
        System.out.println("Customers Sorted By Address.. are");
        while(custIter.hasNext())
        {
            Customer customer = custIter.next();
            System.out.println(customer);
        }
        return customers;
    }
    public ArrayList <Customer> getCustomersSortedByPurchaseValue()
    {
        Collections.sort(customers);
        Iterator <Customer> custIter = customers.iterator();
        System.out.println("Customers Sorted By PurchaseValue.. are");
        while(custIter.hasNext())
        {
            Customer customer = custIter.next();
            System.out.println(customer);
        }
        return customers;
    }

}
