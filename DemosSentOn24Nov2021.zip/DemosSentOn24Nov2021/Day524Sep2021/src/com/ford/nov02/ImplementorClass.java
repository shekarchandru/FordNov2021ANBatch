package com.ford.nov02;

public class ImplementorClass {

    public void callParserMethod(Parser p,String fileType)
    {
        p.parseFile(fileType);
    }
}
