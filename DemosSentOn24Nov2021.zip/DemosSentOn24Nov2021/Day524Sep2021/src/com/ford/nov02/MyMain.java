package com.ford.nov02;

public class MyMain {
    public static void main(String[] args) {
        ImplementorClass implementor = new ImplementorClass();
        Parser parser;
        parser = new JSONParser();
        parser.viewContents();
        implementor.callParserMethod(parser,"JSONFile");
        parser = new XMLParser();
        implementor.callParserMethod(parser,"XMLFile");
        parser = new PDFParser();
        implementor.callParserMethod(parser,"PDFFile");

       // Parser p1 = new Parser(); Not allowed to instantiate abstract class
        //Final Class Must be mandatorily Instantiated to use the features
        MyFinalClass mfc = new MyFinalClass();
        mfc.finalMethod1();
        mfc.finalMethod2();
        mfc.finalMethod2(100,200);


    }
}
