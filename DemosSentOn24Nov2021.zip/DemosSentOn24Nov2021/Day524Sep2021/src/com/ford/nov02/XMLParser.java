package com.ford.nov02;

public class XMLParser extends Parser {
    @Override
    public void parseFile(String fileType) {
        System.out.println("Parsed XML File "+fileType);

    }

    @Override
    public void method1() {

    }
}
