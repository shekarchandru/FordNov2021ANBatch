package com.ford.nov5.files;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class SampleFileStreamWriter {
    boolean flag = false;
    File file1;
    FileOutputStream fos;
    String str = new String("We are writing to Files");
    byte myBytes[] = new byte[100];

    public boolean writeToFileStream()
    {
        String pathName = "C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch04-01Nov2021AN\\Files\\Customer.txt";
        file1 = new File(pathName);
        try {
            fos = new FileOutputStream(file1);
            myBytes = str.getBytes();
            fos.write(myBytes);
            System.out.println("We wrote to Byte Stream Sccessfully....");
            flag = true;
            fos.flush();
            fos.close();
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
            flag = false;
        } catch (IOException ioe) {
            ioe.printStackTrace();
            flag = false;
        }
        return flag;
    }

    public static void main(String[] args) {

        SampleFileStreamWriter streamWriter = new SampleFileStreamWriter();
        streamWriter.writeToFileStream();
    }


}
