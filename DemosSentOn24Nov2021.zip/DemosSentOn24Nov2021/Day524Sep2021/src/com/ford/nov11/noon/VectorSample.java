package com.ford.nov11.noon;

import java.util.Enumeration;
import java.util.Vector;

public class VectorSample {

    Vector <Customer> customerVector;
    boolean flag;

    public VectorSample()
    {
        flag = false;
        customerVector = new Vector(5,8);
        customerVector.addElement(new Customer("C001","Ramesh","RTNagar","9849999498",1000.0f,"Product1"));
        customerVector.addElement(new Customer("C002","Mahesh","Jayanagar","9849934498",2000.0f,"Product2"));
        customerVector.addElement(new Customer("C003","Sumanth","Vijayanagar","9845699498",3000.0f,"Product3"));
        customerVector.addElement(new Customer("C004","Kiran","Malleswaram","9849996798",4000.0f,"Product4"));
        customerVector.addElement(new Customer("C005","Rakesh","Vijayanagar","9834999498",5000.0f,"Product5"));
    }

    public boolean fetchVectorObjects()
    {
       if(displayCustomerVectorObjects(customerVector)) {
           flag = true;
       }
        System.out.println("The Initial Size "+customerVector.size());
        System.out.println("The Initial Capacity "+customerVector.capacity());
       customerVector.insertElementAt(new Customer("C006","Kishore","Gandhinagar","9834967498",6000.0f,"Product5"),4);
       customerVector.insertElementAt(new Customer("C007","Sumanth","RTNagar","9834645498",5000.0f,"Product6"),3);
        System.out.println("The Initial Size after adding 2 Objects :"+customerVector.size());
        System.out.println("The Initial Capacity after adding 2 Objects :"+customerVector.capacity());
       if(displayCustomerVectorObjects(customerVector)) {
            flag = true;
        }
       customerVector.removeElementAt(3);
        if(displayCustomerVectorObjects(customerVector)) {
            flag = true;
        }
        return flag;
    }
    public boolean displayCustomerVectorObjects(Vector <Customer> customerVector)
    {
        System.out.println("--------------------------------------");

        Enumeration <Customer> customerEnum;
        try {
            customerEnum = customerVector.elements();
            while (customerEnum.hasMoreElements()) {
                Customer customer = customerEnum.nextElement();
                System.out.println("Vector Element is "+customer);
            }
            flag = true;
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }


}
