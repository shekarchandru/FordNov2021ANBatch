package com.ford.anoon;

import java.util.Scanner;

public class Furniture {

    /* private public protected default
    * */
    /*private*/protected int length;
    /*private*/protected  int width;
    /*private*/protected int height;
    Scanner scan1;

    public Furniture() {
        super();
        scan1 = new Scanner(System.in);
    }

    public Furniture(int length, int width, int height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }
    public void acceptFurnitureDetails()
    {
        System.out.println("Enter the Furniture Details....");
        System.out.println("Enter the Length ");
        length = scan1.nextInt();
        System.out.println("Enter the Width ");
        width = scan1.nextInt();
        System.out.println("Enter the Height");
        height = scan1.nextInt();
    }
    public void displayFurnitureDetails()
    {
        System.out.println("Furniture Details are...");
        System.out.println("The length is "+length);
        System.out.println("The width is "+width);
        System.out.println("The height is "+height);
    }
}
