package com.ford.except;

public class ConstructorOverloadingDer extends  ConstructorOverloading{
String p,q;


    public ConstructorOverloadingDer(int x, int y) {
        super(x, y);
    }

    public ConstructorOverloadingDer(int x, int y, String p, String q) {
        super(x, y);
        this.p = p;
        this.q = q;
    }

    public static void main(String[] args) {
        ConstructorOverloadingDer coor = new ConstructorOverloadingDer(10,20,"hello","world");

    }
}


