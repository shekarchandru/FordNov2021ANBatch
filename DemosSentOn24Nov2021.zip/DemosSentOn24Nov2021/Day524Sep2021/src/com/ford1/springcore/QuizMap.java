package com.ford1.springcore;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class QuizMap {
    String quizId;
    String topic;
    String question;
    Map <User,AnswerN> answers;

    public QuizMap() {
    }

    public QuizMap(String quizId, String topic, String question, Map<User, AnswerN> answers) {
        this.quizId = quizId;
        this.topic = topic;
        this.question = question;
        this.answers = answers;
    }
    public void displayQuizMapDetails()
    {
        System.out.println("Quiz Details are...");
        System.out.println("Quiz Id is "+quizId);
        System.out.println("The Topic Of the Quiz is "+topic);
        System.out.println("The Question is "+question);

        Set <User> userKeys = answers.keySet();
        Iterator <User> users = userKeys.iterator();
        while(users.hasNext())
        {
            User user = users.next();
            AnswerN answerN = answers.get(user);
            System.out.println("The Answer Provided By the User "+user+" Is :"+answerN);
        }

    }
}
