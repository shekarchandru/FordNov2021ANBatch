package com.ford1.springcorenoon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuizMapInjector {

    ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/QuizMapContext.xml");
    boolean flag = false;

    public boolean injectQuizMap1()
    {
        try
        {
            QuizMap quizMap1 = (QuizMap)context.getBean("quizMap1");
            quizMap1.displayQuizMapDetails();
            flag = true;

        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectQuizMap2()
    {
        try
        {
            QuizMap quizMap2 = (QuizMap)context.getBean("quizMap2");
            quizMap2.displayQuizMapDetails();
            flag = true;

        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return flag;
    }


}
