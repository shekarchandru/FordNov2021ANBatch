package com.ford1.springcorenoon;

public class Employee {

    String employeeId;
    String employeeName;
    String employeePhone;
    float employeeSalary;
    Address employeeAddress;

    public Employee() {
    }

    public Employee(String employeeId, String employeeName) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
    }

    public Employee(String employeeId, String employeeName, String employeePhone) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeePhone = employeePhone;
    }

    public Employee(String employeeId, String employeeName, String employeePhone, float employeeSalary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeePhone = employeePhone;
        this.employeeSalary = employeeSalary;
    }

    public Employee(String employeeId, String employeeName, String employeePhone, float employeeSalary, Address employeeAddress) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.employeePhone = employeePhone;
        this.employeeSalary = employeeSalary;
        this.employeeAddress = employeeAddress;
    }

    public void displayEmployeeDetails()
    {
        System.out.println("Employee Details are....");
        System.out.println("Employee Id :"+employeeId);
        System.out.println("Employee Name :"+employeeName);
        System.out.println("Employee Phone :"+employeePhone);
        System.out.println("Employee Salary :"+employeeSalary);
        System.out.println("And the Address is ...");
        System.out.println(employeeAddress);

    }
}
