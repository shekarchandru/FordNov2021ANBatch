package com.ford2.setter.noon;

public class Appraisal {

    String appraisalId;
    String appraiserName;
    String appraisalDate;

    public String getAppraisalId() {
        return appraisalId;
    }

    public void setAppraisalId(String appraisalId) {
        this.appraisalId = appraisalId;
    }

    public String getAppraiserName() {
        return appraiserName;
    }

    public void setAppraiserName(String appraiserName) {
        this.appraiserName = appraiserName;
    }

    public String getAppraisalDate() {
        return appraisalDate;
    }

    public void setAppraisalDate(String appraisalDate) {
        this.appraisalDate = appraisalDate;
    }

    @Override
    public String toString() {
        return "Appraisal{" +
                "appraisalId='" + appraisalId + '\'' +
                ", appraiserName='" + appraiserName + '\'' +
                ", appraisalDate='" + appraisalDate + '\'' +
                '}';
    }
}
