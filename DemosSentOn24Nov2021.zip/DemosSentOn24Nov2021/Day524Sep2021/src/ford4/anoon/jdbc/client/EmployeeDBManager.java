package ford4.anoon.jdbc.client;

import ford4.anoon.jdbc.model.Employee;
import ford4.anoon.jdbc.service.EmployeeService;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class EmployeeDBManager {

    Scanner scan1;
    String reply = "yes";
    int choice;
    EmployeeService employeeService;

    public EmployeeDBManager() {
        scan1 = new Scanner(System.in);
        employeeService = new EmployeeService();
    }

    public void displayMenu()
    {
        while(reply.equals("yes") || reply.equals("YES") || reply.equals("Yes")) {
            System.out.println("-----------------------------MAIN MENU--------------------------------");
            System.out.println("1.Get All Employees data...");
            System.out.println("2.Get Employee Record By ID...");
            System.out.println("3.Insert Employee...");
            System.out.println("4.Update Employee...");
            System.out.println("5.Delete Employee By ID...");
            System.out.println("6.Exit Main Menu...");
            System.out.println("-----------------------------MAIN MENU ENDS--------------------------------");
            System.out.println("Enter Your Choice...");
            choice = scan1.nextInt();
            switch (choice) {
                case 1: {
                    System.out.println("Viewing All Records...");
                    List <Employee> employees = employeeService.getEmployeeRecords();
                    Iterator <Employee> empIter = employees.iterator();
                    System.out.println("Employee Records are.......");
                    while(empIter.hasNext())
                    {
                        Employee employee = empIter.next();
                        System.out.println(employee);
                    }
                    break;
                }
                case 2: {
                    System.out.println("Viewing Employee Record By ID...");
                    String employeeId;
                    System.out.println("Enter The ID of the Employee, whose Record you wish to see...");
                    employeeId = scan1.next();
                    Employee employee = employeeService.getEmployeeRecordById(employeeId);
                    if(employee != null) {
                        System.out.println("The Record for the Employee with an ID :" + employeeId + " is ");
                        System.out.println(employee);
                    }
                    else
                    {
                        System.out.println("Employee Not Found For the ID "+employeeId);
                    }
                    break;
                }
                case 3: {
                    System.out.println("Inserting Employee Record...");

                    String empId;

                   /*   System.out.println("Enter the Employee ID");
                    empId = scan1.next();
                    System.out.println("Enter the Employee Name ");
                    empName = scan1.next();
                    System.out.println("Enter the Employee Address ");
                    empAddress = scan1.next();
                    System.out.println("Enter the Employee Phone");
                    empPhone = scan1.next();
                    System.out.println("Enter the Employee Salary");
                    empSalary = scan1.nextFloat();
                    System.out.println("Enter the Employee Tax");
                    empTax = scan1.nextInt();
                    Employee employee = new Employee(empId,empName,empAddress,empPhone,empSalary,empTax);*/
                    System.out.println("Enter the Employee ID");
                    empId = scan1.next();
                    Employee employee = acceptEmployeeDetails();
                    employee.setEmployeeId(empId);
                    if(employeeService.insertEmployeeRecord(employee))
                    {
                        System.out.println("Employee Record Inserted Successfully....");
                    }
                    else
                    {
                        System.out.println("Sorry!!! Insertion Failed...");
                    }
                    break;
                }
                case 4: {
                    System.out.println("Updating Employee Record...");
                    String empId;
                    System.out.println("Enter the ID of the Employee whose record you wish to Update..  ");
                    empId = scan1.next();


                    Employee empUpdate = employeeService.getEmployeeRecordById(empId);
                    if(empUpdate != null) {
                        System.out.println("Current Record of Employee with Id " + empId + " is :");
                        System.out.println(empUpdate);


                  /*  String empName,empAddress,empPhone;
                    float empSalary;
                    int empTax;

                    System.out.println("Enter the Employee Name ");
                    empName = scan1.next();
                    System.out.println("Enter the Employee Address ");
                    empAddress = scan1.next();
                    System.out.println("Enter the Employee Phone");
                    empPhone = scan1.next();
                    System.out.println("Enter the Employee Salary");
                    empSalary = scan1.nextFloat();
                    System.out.println("Enter the Employee Tax");
                    empTax = scan1.nextInt();
                    empUpdate = new Employee(empId,empName,empAddress,empPhone,empSalary,empTax);*/
                        empUpdate = acceptEmployeeDetails();
                        empUpdate.setEmployeeId(empId);
                        if (employeeService.updateEmployeeRecord(empUpdate, empId)) {
                            System.out.println("Employee Record Updated Successfully for the Employee with ID :" + empId);
                        } else {
                            System.out.println("Sorry !!! Updation Failed ....");
                        }
                    }
                    else
                    {
                        System.out.println("Sorry Employee Record Not Found For the ID "+empId);
                    }

                    break;
                }
                case 5: {
                    System.out.println("Deleting Employee Record By Id...");
                    String empId;
                    System.out.println("Enter the ID of the Employee whose Record you wish to delete... " );
                    empId = scan1.next();
                    Employee employeeDel = employeeService.getEmployeeRecordById(empId);
                    if(employeeDel != null) {
                        if (employeeService.deleteEmployeeRecordById(empId)) {
                            System.out.println("Record Deleted Successfully for the Employee with Id " + empId);
                        } else {
                            System.out.println("Sorry !!! Deletion failed...");
                        }
                    }
                    else
                    {
                        System.out.println("Sorry Employee Record Do Not Exits for the Employee Id "+empId);
                    }
                    break;
                }
                case 6: {
                    System.out.println("Exiting Main Menu...");
                    System.exit(0);
                    break;
                }
                default: {
                    System.out.println("Sorry valid Choice. is 0 to 6..");
                    break;
                }
            } // Switch ending
            System.out.println("Do You Wish To Go Back To Main Menu Yes/No");
            reply = scan1.next();
        } // while loop ending
        System.out.println("Exiting Main Menu...");
    } // DisplayMenu() Function Ending

        public Employee acceptEmployeeDetails()
        {
            String empId,empName,empAddress,empPhone;
            float empSalary;
            int empTax;
            System.out.println("Enter the Employee Name ");
            empName = scan1.next();
            System.out.println("Enter the Employee Address ");
            empAddress = scan1.next();
            System.out.println("Enter the Employee Phone");
            empPhone = scan1.next();
            System.out.println("Enter the Employee Salary");
            empSalary = scan1.nextFloat();
            System.out.println("Enter the Employee Tax");
            empTax = scan1.nextInt();
            Employee employee = new Employee(empName,empAddress,empPhone,empSalary,empTax);
            return employee;
        }
       /* public boolean checkIfIDExists(String empId)
        {

        }
        public List <String> getEmployeeIds()
        {

        }*/
}
