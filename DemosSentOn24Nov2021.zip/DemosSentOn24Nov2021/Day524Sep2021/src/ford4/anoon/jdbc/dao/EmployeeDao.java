package ford4.anoon.jdbc.dao;

import ford4.anoon.jdbc.connections.ConnectionClass;
import ford4.anoon.jdbc.model.Employee;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDao {

    Connection myCon;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    ConnectionClass connectionClass;

    public EmployeeDao() {
        connectionClass = new ConnectionClass();
        myCon = connectionClass.getMyConnection();
    }
    public List <Employee> getAllEmployees()
    {
        List <Employee> employees = new ArrayList<Employee>();
        try {
            stmt = myCon.createStatement();
            rs = stmt.executeQuery("select * from Employee");
            while(rs.next())
            {
                Employee e = new Employee();
                String empId = rs.getString(1);
                e.setEmployeeId(empId);
                e.setEmployeeName(rs.getString(2));
                e.setEmployeeAddress(rs.getString(3));
                e.setEmployeePhone(rs.getString(4));
                e.setEmployeeSalary(rs.getFloat(5));
                e.setEmployeeTax(rs.getInt(6));
                employees.add(e);
            }
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }
        return employees;
    }
    public Employee getEmployeeById(String employeeId)
    {
        Employee employee = new Employee();
        String sql = "select * from Employee where EmployeeId = ?";
        try {
            pstmt = myCon.prepareStatement(sql);
            pstmt.setString(1,employeeId);

            rs = pstmt.executeQuery();
            rs.next();
            employee.setEmployeeId(rs.getString(1));
            employee.setEmployeeName(rs.getString(2));
            employee.setEmployeeAddress(rs.getString(3));
            employee.setEmployeePhone(rs.getString(4));
            employee.setEmployeeSalary(rs.getFloat(5));
            employee.setEmployeeTax(rs.getInt(6));
        }
        catch(SQLException sqe)
        {
         //  sqe.printStackTrace();
            employee = null;
        }
        return employee;
    }
    public boolean insertEmployee(Employee employee)
    {
        boolean flag = false;
        String sqlInsert = "insert into Employee values(?,?,?,?,?,?)";
        try {
            pstmt = myCon.prepareStatement(sqlInsert);

            pstmt.setString(1,employee.getEmployeeId());
            pstmt.setString(2,employee.getEmployeeName());
            pstmt.setString(3,employee.getEmployeeAddress());
            pstmt.setString(4,employee.getEmployeePhone());
            pstmt.setFloat(5,employee.getEmployeeSalary());
            pstmt.setInt(6,employee.getEmployeeTax());

            pstmt.execute();
            flag = true;
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean updateEmployee(Employee employee,String empId)
    {
        boolean flag = false;
        String sql = "update Employee set employeeName = ?, employeeAddress = ?, employeePhone = ?, employeeSalary = ?, employeeTax = ? where employeeId = ?";
       try {
           pstmt = myCon.prepareStatement(sql);
           pstmt.setString(1,employee.getEmployeeName());
           pstmt.setString(2,employee.getEmployeeAddress());
           pstmt.setString(3,employee.getEmployeePhone());
           pstmt.setFloat(4,employee.getEmployeeSalary());
           pstmt.setInt(5,employee.getEmployeeTax());
           pstmt.setString(6,empId);
           pstmt.executeUpdate();
           flag = true;

       }
       catch(SQLException sqe)
       {
           sqe.printStackTrace();
           flag = false;
       }
        return flag;
    }
    public boolean deleteEmployeeById(String empId)
    {
        boolean flag = false;
        try {
            pstmt = myCon.prepareStatement("delete from Employee where employeeId = ?");
            pstmt.setString(1,empId);
            pstmt.execute();
            flag = true;
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
