package ford4.anoon.jdbc.connections;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/*
DataConnection.properties
 */
public class ConnectionClass {

    Connection con ;
    String url = "jdbc:mysql://localhost:3306/FordMorn";
    String user="root";
    String password = "MySQL_@123456";
    public Connection getMyConnection()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url, user, password);
        }
        catch(ClassNotFoundException cnfe)
        {
            cnfe.printStackTrace();
        }
        catch(SQLException sqe)
        {
            sqe.printStackTrace();
        }
        return con;
    }
}
