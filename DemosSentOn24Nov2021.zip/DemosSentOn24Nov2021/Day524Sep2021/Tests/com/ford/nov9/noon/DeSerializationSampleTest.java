package com.ford.nov9.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DeSerializationSampleTest {
   DeSerializationSample deSerSample;
    @BeforeEach
    void setUp() {
        deSerSample = new DeSerializationSample();
    }

    @AfterEach
    void tearDown() {
    }
    @Test
    public void shouldDeserializeObject()
    {
       assertTrue( deSerSample.deSerializeEmployeeObject());
    }

}