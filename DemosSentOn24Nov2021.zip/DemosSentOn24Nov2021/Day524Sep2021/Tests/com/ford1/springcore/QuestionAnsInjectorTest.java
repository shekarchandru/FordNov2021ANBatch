package com.ford1.springcore;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QuestionAnsInjectorTest {

    QuestionAnsInjector questionAnsInjector;
    @BeforeEach
    void setUp() {
        questionAnsInjector = new QuestionAnsInjector();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void shouldInjectQuestAns1() {
        assertTrue(questionAnsInjector.injectQuestAns1());
    }

    @Test
    void shouldInjectQuestAns2() {
        assertTrue(questionAnsInjector.injectQuestAns2());
    }
}