package com.ford1.springcore;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InjectorTest {

    Injector injector;
    @BeforeEach
    void setUp() {
        injector = new Injector();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldInjectCustomer()
    {
        assertTrue(injector.injectCustomer());
    }
    @Test
    public void shouldInjectCustomer2()
    {
        assertTrue(injector.injectCustomer2());
    }
    @Test
    public void shouldInjectCustomer3()
    {
        assertTrue(injector.injectCustomer3());
    }
    @Test
    public void shouldInjectCustomer4()
    {
        assertTrue(injector.injectCustomer4());
    }

}