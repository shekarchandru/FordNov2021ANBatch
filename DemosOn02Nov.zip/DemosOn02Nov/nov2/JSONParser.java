package com.ford.noon.nov2;

public class JSONParser extends Parser{
    @Override
    public void parseFile(String fileType) {
        System.out.println("Finished the Parsing of "+fileType);
    }
}
