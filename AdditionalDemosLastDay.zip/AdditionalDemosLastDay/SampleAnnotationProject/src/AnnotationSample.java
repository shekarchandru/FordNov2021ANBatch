import java.util.Date;

class BaseClass
{
	public void display()
	{
		System.out.println(" Displaying Base Class");
	}
}
public class AnnotationSample extends BaseClass {
	
	@Override
	@Deprecated
	@SuppressWarnings("unchecked")
	public void display()
	{
		System.out.println("Displaying Derived Class..");
		  	Date d1 = new Date();
	        System.out.println("The Date is "+d1.getDate());
	        System.out.println("The Month is "+d1.getMonth());
	        System.out.println("the Year is "+d1.getYear());
	}
	public void simpleDisplay()
	{
		System.out.println("Display again");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationSample annotationSample = new AnnotationSample();
		annotationSample.display();
		annotationSample.simpleDisplay();
	}

}
