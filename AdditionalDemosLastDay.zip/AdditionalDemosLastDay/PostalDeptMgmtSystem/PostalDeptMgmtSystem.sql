create table NSCHolderDetails
(
RecordID varchar(20) primary key,
customerId varchar(20),
customerName varchar(30),
customerPhone varchar(20),
customereMail varchar(30),
NSCidNos varchar(200),
dateOfIssue date,
maturityDate date,
denomination int,
noOfCertificates int,
totalCost float,
interestAccumulated float,
taxDeductionOnInterest float,
nettAmtPayable float
)