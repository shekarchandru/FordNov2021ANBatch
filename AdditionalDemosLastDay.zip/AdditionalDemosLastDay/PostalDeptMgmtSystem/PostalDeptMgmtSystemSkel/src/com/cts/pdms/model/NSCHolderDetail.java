package com.cts.pdms.model;

import java.util.Arrays;
import java.util.Date;

public class NSCHolderDetail {

	String recordId;
	String customerId;
	String customerName;
	String customerPhone;
	String customereMail;
	String[] NSCidNos;
	Date dateOfIssue;
	Date maturityDate;
	int denomination;
	int noOfCertificates;
	double totalCost;
	double interestAccumulated;
	double taxDeductionOnInterest;
	double nettAmtPayable;
	
	
	public NSCHolderDetail() {
		super();
	}


	public NSCHolderDetail(String recordId, String customerId, String customerName, String customerPhone,
			String customereMail, String[] nSCidNos, Date dateOfIssue, Date maturityDate, int denomination,
			int noOfCertificates, double totalCost, double interestAccumulated, double taxDeductionOnInterest,
			double nettAmtPayable) {
		super();
		this.recordId = recordId;
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPhone = customerPhone;
		this.customereMail = customereMail;
		NSCidNos = nSCidNos;
		this.dateOfIssue = dateOfIssue;
		this.maturityDate = maturityDate;
		this.denomination = denomination;
		this.noOfCertificates = noOfCertificates;
		this.totalCost = totalCost;
		this.interestAccumulated = interestAccumulated;
		this.taxDeductionOnInterest = taxDeductionOnInterest;
		this.nettAmtPayable = nettAmtPayable;
	}


	public String getRecordId() {
		return recordId;
	}


	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getCustomerPhone() {
		return customerPhone;
	}


	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}


	public String getCustomereMail() {
		return customereMail;
	}


	public void setCustomereMail(String customereMail) {
		this.customereMail = customereMail;
	}


	public String[] getNSCidNos() {
		return NSCidNos;
	}


	public void setNSCidNos(String[] nSCidNos) {
		NSCidNos = nSCidNos;
	}


	public Date getDateOfIssue() {
		return dateOfIssue;
	}


	public void setDateOfIssue(Date dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}


	public Date getMaturityDate() {
		return maturityDate;
	}


	public void setMaturityDate(Date maturityDate) {
		this.maturityDate = maturityDate;
	}


	public int getDenomination() {
		return denomination;
	}


	public void setDenomination(int denomination) {
		this.denomination = denomination;
	}


	public int getNoOfCertificates() {
		return noOfCertificates;
	}


	public void setNoOfCertificates(int noOfCertificates) {
		this.noOfCertificates = noOfCertificates;
	}


	public double getTotalCost() {
		return totalCost;
	}


	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}


	public double getInterestAccumulated() {
		return interestAccumulated;
	}


	public void setInterestAccumulated(double interestAccumulated) {
		this.interestAccumulated = interestAccumulated;
	}


	public double getTaxDeductionOnInterest() {
		return taxDeductionOnInterest;
	}


	public void setTaxDeductionOnInterest(double taxDeductionOnInterest) {
		this.taxDeductionOnInterest = taxDeductionOnInterest;
	}


	public double getNettAmtPayable() {
		return nettAmtPayable;
	}


	public void setNettAmtPayable(double nettAmtPayable) {
		this.nettAmtPayable = nettAmtPayable;
	}


	@Override
	public String toString() {
		return "NSCHolderDetail [recordId=" + recordId + ", customerId=" + customerId + ", customerName=" + customerName
				+ ", customerPhone=" + customerPhone + ", customereMail=" + customereMail + ", NSCidNos="
				+ Arrays.toString(NSCidNos) + ", dateOfIssue=" + dateOfIssue + ", maturityDate=" + maturityDate
				+ ", denomination=" + denomination + ", noOfCertificates=" + noOfCertificates + ", totalCost="
				+ totalCost + ", interestAccumulated=" + interestAccumulated + ", taxDeductionOnInterest="
				+ taxDeductionOnInterest + ", nettAmtPayable=" + nettAmtPayable + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
}
