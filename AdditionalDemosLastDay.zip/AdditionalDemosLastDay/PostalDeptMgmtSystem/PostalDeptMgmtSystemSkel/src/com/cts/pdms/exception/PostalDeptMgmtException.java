package com.cts.pdms.exception;

public class PostalDeptMgmtException extends Exception{
	


public PostalDeptMgmtException() {
	super();
}


public PostalDeptMgmtException(String strMsg1, Throwable strMsg2) {
	super();

}


}
