package com.cts.pdms.client;

import com.cts.pdms.service.PostalDeptMgmtService;

public class PostalDeptMgmt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PostalDeptMgmtService postService = new PostalDeptMgmtService();
	}

}
