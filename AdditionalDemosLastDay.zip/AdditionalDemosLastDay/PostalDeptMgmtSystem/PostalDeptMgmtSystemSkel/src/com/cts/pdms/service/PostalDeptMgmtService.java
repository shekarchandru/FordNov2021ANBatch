package com.cts.pdms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.pdms.dao.PostalDeptMgmtDAO;
import com.cts.pdms.exception.PostalDeptMgmtException;
import com.cts.pdms.model.NSCHolderDetail;
import com.cts.pdms.util.ApplicationUtil;

public class PostalDeptMgmtService {

	
	/*
	 * 
	 * String propertyId;String ownersName;double areaInSqFt;String propertyType;double taxAmount;
		Date dateOfPyt;Date dueDate;double revisedTaxAmt;
	 */
	
	public static ArrayList <NSCHolderDetail> buildNSCHolderList(List <String> nscHolderRecords) {
	
		final String COMMADELIMITER = ",";
		ArrayList <NSCHolderDetail> nscHolderList = new ArrayList<NSCHolderDetail>();
		
		return nscHolderList;
	}
	
	public boolean addNSCHolderDetails(String inputFeed) throws PostalDeptMgmtException {
	//	EmployeeDAO employeeDao = new EmployeeDAO();
	//	return employeeDao.addEmployeeDetails(buildEmployeeList(ApplicationUtil.readFile(inputFeed)));
		PostalDeptMgmtDAO postMgmtDAO = new PostalDeptMgmtDAO();
		return postMgmtDAO.insertNSCHolderDetails(buildNSCHolderList(ApplicationUtil.readFile(inputFeed)));
		 
	}
	
	public static double calculateTotalInterest(double totCost) {
		double totalAccuInterest=0.0;
		
		
		return totalAccuInterest;
	}
	
	public static double calculateTaxLiability(double totInterest) 
	{
		double totalTaxLiable=0.0;
		
		return totalTaxLiable;
		
	}
}
