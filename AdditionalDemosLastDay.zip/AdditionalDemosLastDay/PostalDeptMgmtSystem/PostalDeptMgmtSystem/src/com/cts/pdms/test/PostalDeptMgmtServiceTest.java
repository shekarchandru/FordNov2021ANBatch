package com.cts.pdms.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import com.cts.pdms.exception.PostalDeptMgmtException;
import com.cts.pdms.model.NSCHolderDetail;
import com.cts.pdms.service.PostalDeptMgmtService;
import com.cts.pdms.util.ApplicationUtil;

class PostalDeptMgmtServiceTest {

	private PostalDeptMgmtService postDeptMgtSrvc;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		postDeptMgtSrvc = new PostalDeptMgmtService();
	}

	@AfterEach
	void tearDown() throws Exception {
		postDeptMgtSrvc = null;
	}
/*
 * [NSCHolderDetail [recordId=R001, customerId=C001, customerName=Girish Kumar, customerPhone=9838838883, customereMail=Giri@gmail.com, NSCidNos=[nsc01, nsc02, nsc03, nsc04, nsc50], dateOfIssue=Tue May 26 00:00:00 IST 2015, maturityDate=Tue May 26 00:00:00 IST 2020, denomination=1000, noOfCertificates=50, totalCost=50000.0, interestAccumulated=49618.75, taxDeductionOnInterest=2480.9375, nettAmtPayable=97137.8125], 
 * NSCHolderDetail [recordId=R002, customerId=C002, customerName=Mahesh Kumar, customerPhone=9837468883, customereMail=Mah@gmail.com, NSCidNos=[nsc01, nsc02, nsc03, nsc04, nsc50], dateOfIssue=Tue May 26 00:00:00 IST 2015, maturityDate=Tue May 26 00:00:00 IST 2020, denomination=5000, noOfCertificates=5, totalCost=25000.0, interestAccumulated=24809.375, taxDeductionOnInterest=1240.46875, nettAmtPayable=48568.90625], 
 * NSCHolderDetail [recordId=R003, customerId=C003, customerName=Rakesh Kumar, customerPhone=9838647783, customereMail=Rak@gmail.com, NSCidNos=[nsc01, nsc02, nsc03, nsc04, nsc50], dateOfIssue=Tue May 26 00:00:00 IST 2015, maturityDate=Tue May 26 00:00:00 IST 2020, denomination=10000, noOfCertificates=5, totalCost=50000.0, interestAccumulated=49618.75, taxDeductionOnInterest=2480.9375, nettAmtPayable=97137.8125], 
 * NSCHolderDetail [recordId=R004, customerId=C004, customerName=Rajesh Kumar, customerPhone=9534638883, customereMail=Raj@gmail.com, NSCidNos=[nsc01, nsc02, nsc03, nsc04, nsc50], dateOfIssue=Tue May 26 00:00:00 IST 2015, maturityDate=Tue May 26 00:00:00 IST 2020, denomination=10000, noOfCertificates=5, totalCost=50000.0, interestAccumulated=49618.75, taxDeductionOnInterest=2480.9375, nettAmtPayable=97137.8125], 
 * NSCHolderDetail [recordId=R005, customerId=C005, customerName=Milind Kumar, customerPhone=9838887653, customereMail=Mili@gmail.com, NSCidNos=[nsc01, nsc02, nsc03, nsc04, nsc50], dateOfIssue=Tue May 26 00:00:00 IST 2015, maturityDate=Tue May 26 00:00:00 IST 2020, denomination=5000, noOfCertificates=5, totalCost=25000.0, interestAccumulated=24809.375, taxDeductionOnInterest=1240.46875, nettAmtPayable=48568.90625], 
 * NSCHolderDetail [recordId=R006, customerId=C006, customerName=Kiran Kumar, customerPhone=8374838883, customereMail=Kir@gmail.com, NSCidNos=[nsc01, nsc02, nsc03, nsc04, nsc50], dateOfIssue=Tue May 26 00:00:00 IST 2015, maturityDate=Tue May 26 00:00:00 IST 2020, denomination=5000, noOfCertificates=10, totalCost=50000.0, interestAccumulated=49618.75, taxDeductionOnInterest=2480.9375, nettAmtPayable=97137.8125
 */
	@Test
	void testBuildNSCHolderList() {
		ArrayList <NSCHolderDetail> nscHolderList = new ArrayList<NSCHolderDetail> ();
		String[] nscNos = {"nsc01","nsc02","nsc03","nsc04","nsc50"};
		nscHolderList.add(new NSCHolderDetail("R001", "C001", "Girish Kumar", "9838838883","Giri@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),1000,50, 50000, 49618.75, 2480.9375,97137.8125));
		nscHolderList.add(new NSCHolderDetail("R002", "C002", "Mahesh Kumar", "9837468883","Mah@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),5000,5, 25000, 24809.375, 1240.46875,48568.90625));
		nscHolderList.add(new NSCHolderDetail("R003", "C003", "Rakesh Kumar", "9838647783","Rak@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),10000,5, 50000, 49618.75, 2480.9375,97137.8125));
		nscHolderList.add(new NSCHolderDetail("R004", "C004", "Rajesh Kumar", "9534638883","Raj@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),10000,5, 50000, 49618.75, 2480.9375,97137.8125));
		nscHolderList.add(new NSCHolderDetail("R005", "C005", "Milind Kumar", "9838887653","Mili@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),5000,5,  25000, 24809.375, 1240.46875,48568.90625));
		nscHolderList.add(new NSCHolderDetail("R006", "C006", "Kiran Kumar", "8374838883","Kir@gmail.com",nscNos , ApplicationUtil.stringToDateConverter("2015-05-26"), ApplicationUtil.stringToDateConverter("2020-05-26"),5000,10, 50000, 49618.75, 2480.9375,97137.8125));
		try {
			assertEquals(nscHolderList,
					postDeptMgtSrvc.buildNSCHolderList(ApplicationUtil.readFile("inputfeed.txt")));
		} catch (PostalDeptMgmtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testAddNSCHolderDetails() {
		try {
			assertTrue(postDeptMgtSrvc.addNSCHolderDetails("inputfeed.txt"));
		} catch (PostalDeptMgmtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*@Test
	void testCalculateTotalInterest() {
		fail("Not yet implemented");
	}

	@Test
	void testCalculateTaxLiability() {
		fail("Not yet implemented");
	}*/

}
