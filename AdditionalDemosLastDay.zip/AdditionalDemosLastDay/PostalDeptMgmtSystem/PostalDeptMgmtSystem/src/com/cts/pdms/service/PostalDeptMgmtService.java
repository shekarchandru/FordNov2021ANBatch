package com.cts.pdms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.pdms.dao.PostalDeptMgmtDAO;
import com.cts.pdms.exception.PostalDeptMgmtException;
import com.cts.pdms.model.NSCHolderDetail;
import com.cts.pdms.util.ApplicationUtil;

public class PostalDeptMgmtService {
	/*
	 * 
	 * String propertyId;String ownersName;double areaInSqFt;String propertyType;double taxAmount;
		Date dateOfPyt;Date dueDate;double revisedTaxAmt;
	 */
	
	public static ArrayList <NSCHolderDetail> buildNSCHolderList(List <String> nscHolderRecords) {
	//"R001,C001,Rakesh,," arr[]
		final String COMMADELIMITER = ",";
		ArrayList <NSCHolderDetail> nscHolderList = new ArrayList<NSCHolderDetail>();
		
		for(String eachRecord : nscHolderRecords){
			
				String nscHolderDetailFields[]= eachRecord.split(COMMADELIMITER);
				
				
			//	Date dueDate =  ApplicationUtil.stringToDateConverter(nscHolderDetailFields[6]);
				Date dtOfResolution =ApplicationUtil.stringToDateConverter(nscHolderDetailFields[7]);
				NSCHolderDetail nscHolderRecord = new NSCHolderDetail();
				
				nscHolderRecord.setRecordId(nscHolderDetailFields[0]);
				nscHolderRecord.setCustomerId(nscHolderDetailFields[1]);
				nscHolderRecord.setCustomerName(nscHolderDetailFields[2]);
				nscHolderRecord.setCustomerPhone(nscHolderDetailFields[3]);
				nscHolderRecord.setCustomereMail(nscHolderDetailFields[4]);
				
				String[] nscIds = nscHolderDetailFields[5].split(";");
				nscHolderRecord.setNSCidNos(nscIds);
				
				Date dateOfIssue = ApplicationUtil.stringToDateConverter(nscHolderDetailFields[6]);
				nscHolderRecord.setDateOfIssue(dateOfIssue);
				
				Date maturityDate = ApplicationUtil.stringToDateConverter(nscHolderDetailFields[7]);
				nscHolderRecord.setMaturityDate(maturityDate);
				nscHolderRecord.setDenomination(Integer.parseInt(nscHolderDetailFields[8]));
				nscHolderRecord.setNoOfCertificates(Integer.parseInt(nscHolderDetailFields[9]));
				nscHolderRecord.setTotalCost(Double.parseDouble(nscHolderDetailFields[10]));
				
				double interestAccumulated;
				double totalCost = Double.parseDouble(nscHolderDetailFields[10]);
				interestAccumulated = calculateTotalInterest(totalCost);
				//System.out.println("Interest acc"+interestAccumulated);
				nscHolderRecord.setInterestAccumulated(interestAccumulated);
				
				double taxLiability;
				taxLiability = calculateTaxLiability(interestAccumulated);
				//System.out.println("taxLiable "+taxLiability);
				nscHolderRecord.setTaxDeductionOnInterest(taxLiability);
				
				
				double totalAmtPayable = (totalCost + interestAccumulated) - taxLiability;
				nscHolderRecord.setNettAmtPayable(totalAmtPayable);
				
				
				nscHolderList.add(nscHolderRecord);
				
		}
	//	System.out.println(nscHolderList);
		return nscHolderList;
	}
	
	public boolean addNSCHolderDetails(String inputFeed) throws PostalDeptMgmtException {
	//	EmployeeDAO employeeDao = new EmployeeDAO();
	//	return employeeDao.addEmployeeDetails(buildEmployeeList(ApplicationUtil.readFile(inputFeed)));
		PostalDeptMgmtDAO postMgmtDAO = new PostalDeptMgmtDAO();
		return postMgmtDAO.insertNSCHolderDetails(buildNSCHolderList(ApplicationUtil.readFile(inputFeed)));
		 
	}
	
	public static double calculateTotalInterest(double totCost) {
		double totalAccuInterest=0.0;
		for(int i=0;i<5;i++)
		{
			totalAccuInterest = totalAccuInterest + ((totCost+totalAccuInterest) * (i+1) * 5)/100;
		}
	//	50000 ->0 + (50000+0)*(5/100) x+(totcost+)
		return totalAccuInterest;
	}
	
	public static double calculateTaxLiability(double totInterest) 
	{
		double totalTaxLiable=0.0;
		if((totInterest >= 1.0) &&(totInterest <= 100000.0))
		{
		//	System.out.println("In range1"+totInterest);
			totalTaxLiable = (5.0 / 100.0)*totInterest;
		//	System.out.println("tax Liable in calculator "+totalTaxLiable);
		}
		else if((totInterest > 100000.0) &&(totInterest <= 500000.0))
		{
			totalTaxLiable = (10.0 / 100.0)*totInterest;
		}
		else if((totInterest > 500000.0) &&(totInterest <= 1000000.0))
		{
			totalTaxLiable = (20.0 / 100.0)*totInterest;
		}
		else if((totInterest > 1000000.0))
		{
			totalTaxLiable = (30.0 / 100.0)*totInterest;
		}
		else
		{
			totalTaxLiable = 0.0;
		}
		
		return totalTaxLiable;
		
	}
}
