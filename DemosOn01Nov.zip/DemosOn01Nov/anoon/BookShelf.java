package com.ford.anoon;

public class BookShelf extends Furniture {

    int noOfShelves;

    public BookShelf() {
        super();
        // all statements are blow the above statement
    }

    public BookShelf(int noOfShelves) {
        this.noOfShelves = noOfShelves;
    }
  public BookShelf(int noOfShelves,int length,int width,int height)
    {
        super(length,width,height);
       this.noOfShelves = noOfShelves;
    }  /**/
    public void acceptBookShelfDetails()
    {
      /*  System.out.println("Enter the Length ");
        length = scan1.nextInt();
        System.out.println("Enter the Width ");
        width = scan1.nextInt();
        System.out.println("Enter the Height");
        height = scan1.nextInt();*/
        super.acceptFurnitureDetails();
        System.out.println("Enter No Of shelves..");
        noOfShelves = scan1.nextInt();
    }
    public void displayBookShelfDetails()
    {
       /* System.out.println("The length is "+length);
        System.out.println("The width is "+width);
        System.out.println("The height is "+height);*/
        super.displayFurnitureDetails();
        System.out.println("The No of shelves is "+noOfShelves);
    }
}
