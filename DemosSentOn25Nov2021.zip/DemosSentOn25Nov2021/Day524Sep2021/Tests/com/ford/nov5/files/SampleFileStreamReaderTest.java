package com.ford.nov5.files;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SampleFileStreamReaderTest {

    SampleFileStreamReader sReader;
    @BeforeEach
    void setUp() {
        sReader = new SampleFileStreamReader();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldReadFromFileStream()
    {
        assertTrue(sReader.readFromFileStream());
    }

}