package com.ford.nov8.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BufferedOutputStreamOutSampleTest {
BufferedOutputStreamOutSample boSample;
    @BeforeEach
    void setUp() {
        boSample = new BufferedOutputStreamOutSample();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    public void shouldWriteToConsoleThruBuffer()
    {
        assertTrue(boSample.writeToConsoleThruBuffer());
    }

}