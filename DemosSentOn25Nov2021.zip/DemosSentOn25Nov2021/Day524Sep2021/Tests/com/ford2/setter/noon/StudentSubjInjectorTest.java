package com.ford2.setter.noon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentSubjInjectorTest {
    StudentSubjInjector studentSubjInjector;

    @BeforeEach
    void setUp() {
        studentSubjInjector = new StudentSubjInjector();
    }

    @AfterEach
    void tearDown() {
        studentSubjInjector = null;
    }

    @Test
    void shouldInjectStudent1() {
        assertTrue(studentSubjInjector.injectStudent1());
    }

    @Test
    void shouldInjectStudent2() {
        assertTrue(studentSubjInjector.injectStudent2());
    }
}