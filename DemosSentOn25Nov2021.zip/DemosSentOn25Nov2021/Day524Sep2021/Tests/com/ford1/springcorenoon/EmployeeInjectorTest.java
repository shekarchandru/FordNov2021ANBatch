package com.ford1.springcorenoon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeInjectorTest {
EmployeeInjector employeeInjector;
    @BeforeEach
    void setUp() {
        employeeInjector = new EmployeeInjector();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void shouldInjectEmployee1() {
        assertTrue(employeeInjector.injectEmployee1());
    }
    @Test
    void shouldInjectEmployee2() {
        assertTrue(employeeInjector.injectEmployee2());
    }
    @Test
    void shouldInjectEmployee3() {
        assertTrue(employeeInjector.injectEmployee3());
    }
    @Test
    void shouldInjectEmployee4() {
        assertTrue(employeeInjector.injectEmployee4());
    }
}