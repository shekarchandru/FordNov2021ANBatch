package com.ford1.springcorenoon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QuizMapInjectorTest {

    QuizMapInjector quizMapInjector;
    @BeforeEach
    void setUp() {
        quizMapInjector = new QuizMapInjector();
    }

    @AfterEach
    void tearDown() {
        quizMapInjector = null;
    }

    @Test
    void shouldInjectQuizMap1() {
        assertTrue(quizMapInjector.injectQuizMap1());
    }

    @Test
    void shouldInjectQuizMap2() {
        assertTrue(quizMapInjector.injectQuizMap2());
    }
}