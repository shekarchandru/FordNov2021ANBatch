package com.ford1.springcorenoon;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class QuizInjectorTest {
    QuizInjector quizInjector;
    @BeforeEach
    void setUp() {
        quizInjector = new QuizInjector();
    }

    @AfterEach
    void tearDown() {
        quizInjector = null;
    }

    @Test
    void shouldInjectQuiz1() {
        assertTrue(quizInjector.injectQuiz1());

    }

    @Test
    void shouldInjectQuiz2() {
        assertTrue(quizInjector.injectQuiz2());
    }
}