package ford4.anoon.jdbc.client;

public class EmployeeDBClient {
    public static void main(String[] args) {
        EmployeeDBManager employeeDBManager = new EmployeeDBManager();
        employeeDBManager.displayMenu();
    }
}
