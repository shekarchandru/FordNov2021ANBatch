package ford4.anoon.jdbc.service;





import ford4.anoon.jdbc.dao.EmployeeDao;
import ford4.anoon.jdbc.model.Employee;
import java.util.List;

public class EmployeeService {

    EmployeeDao employeeDAO;
    public EmployeeService() {
        employeeDAO = new EmployeeDao();
    }

    public List <Employee> getEmployeeRecords()
    {
        return employeeDAO.getAllEmployees();
    }
    public Employee getEmployeeRecordById(String empId)
    {
        return employeeDAO.getEmployeeById(empId);
    }
    public boolean insertEmployeeRecord(Employee employee)
    {
        return employeeDAO.insertEmployee(employee);
    }
    public boolean updateEmployeeRecord(Employee employee,String empId)
    {
        return employeeDAO.updateEmployee(employee,empId);
    }
    public boolean deleteEmployeeRecordById(String empId)
    {
        return employeeDAO.deleteEmployeeById(empId);
    }
    public String getMaxEmployeeId()
    {
        return employeeDAO.getMaxEmployeeId();
    }
}
