package com.ford2.setter.noon;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Employee {
    String employeeId;
    String employeeName;
    String employeePhone;
    Map <String,String> projectGrades;
    Map <Appraisal,AppraisalReport> appraisalReports;

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeePhone() {
        return employeePhone;
    }

    public void setEmployeePhone(String employeePhone) {
        this.employeePhone = employeePhone;
    }

    public Map<String, String> getProjectGrades() {
        return projectGrades;
    }

    public void setProjectGrades(Map<String, String> projectGrades) {
        this.projectGrades = projectGrades;
    }

    public Map<Appraisal, AppraisalReport> getAppraisalReports() {
        return appraisalReports;
    }

    public void setAppraisalReports(Map<Appraisal, AppraisalReport> appraisalReports) {
        this.appraisalReports = appraisalReports;
    }

    public void displayEmployeeDetails()
    {
        System.out.println("Employee Details are ...");
        System.out.println("Employee Id :"+employeeId);
        System.out.println("Employee Name :"+employeeName);
        System.out.println("Employee Phone :"+employeePhone);
        System.out.println("Project Grade Details are.................");
        Set <String> projectKeySet = projectGrades.keySet();
        Iterator <String> projectKeyIter = projectKeySet.iterator();
        while(projectKeyIter.hasNext())
        {
            String project = projectKeyIter.next();
            System.out.println("The Grade achieved for the Project "+project+" is  :"+projectGrades.get(project));
        }
        System.out.println("The Appraisal and Corresponding Report Details are..................");
        Set <Appraisal> appraisalKeySet  = appraisalReports.keySet();
        Iterator <Appraisal> appraisalKeyIter = appraisalKeySet.iterator();
        while(appraisalKeyIter.hasNext())
        {
            Appraisal appraisal = appraisalKeyIter.next();
            System.out.println("The Appraisal Report for the Appraisal "+appraisal+" Is "+appraisalReports.get(appraisal));
        }
        System.out.println("---------------------------------------------------");

    }
}
