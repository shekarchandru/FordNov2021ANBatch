package com.ford1.springcorenoon;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Quiz {
        String quizId;
        String topic;
        Map <String,String> questionNAns;

    public Quiz() {
    }

    public Quiz(String quizId, String topic, Map<String, String> questionNAns) {
        this.quizId = quizId;
        this.topic = topic;
        this.questionNAns = questionNAns;
    }
    public void displayQuizDetails()
    {
        System.out.println("The Quiz Details are....");
        System.out.println(" Quiz Id is : "+quizId);
        System.out.println("Topic of the Quiz is :"+topic);
        System.out.println("Questions and Corresponding Answers are...");

        Set <Map.Entry <String,String>> quizEntrySet = questionNAns.entrySet();
        Iterator <Map.Entry <String,String>> quizEntry = quizEntrySet.iterator();
        while(quizEntry.hasNext())
        {
             Map.Entry <String,String> myEntry = quizEntry.next();
             String question = myEntry.getKey();
             String answer = myEntry.getValue();
             System.out.println("The Answer for the Question "+question+" is  :"+answer);
        }

    }
}
