package com.ford1.springcorenoon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuestAnswerInjector {
    ApplicationContext context = new ClassPathXmlApplicationContext("contextfiles/QuestionAnswerContext.xml");
    boolean flag = false;

    public boolean injectQuestionAndAnswer1()
    {
        try
        {
            Question question1 = (Question) context.getBean("question1");
            question1.displayQuestionAndAnswers();
            flag = true;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            flag = false;
        }
        return flag;
    }
    public boolean injectQuestionAndAnswer2()
    {
        try
        {
            Question question2 = (Question) context.getBean("question2");
            question2.displayQuestionAndAnswers();
            flag = true;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            flag = false;
        }
        return flag;
    }
}
