package com.ford.nov11.noon;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamSample {

    public static void main(String[] args)
    {
        Function<Programmer, String> getProgrammerName = p -> p.getName();

        Predicate <Programmer> isFemaleProgrammer = p -> p.isFemale();

        Programmer.programmers()
                .stream()
                .filter(Programmer::isFemale)
                .map(Programmer::getName)
                .forEach(System.out::println);
        System.out.println("-----------------------");
        Stream <String> femaleProgs = Programmer.programmers()
                .stream()
                .filter(Programmer::isFemale)
                .map(Programmer::getName);

     List <String> myListFemaleProgs =   femaleProgs.collect(Collectors.toList());
        System.out.println(myListFemaleProgs);
    }


}
