package com.ford.java8;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

class Supplier
{
    String supplierId;
    String supplierName;
    String supplierCity;
    int supplyValue;


    public Supplier() {
    }

    public Supplier(String supplierId, String supplierName, String supplierCity, int supplyValue) {
        this.supplierId = supplierId;
        this.supplierName = supplierName;
        this.supplierCity = supplierCity;
        this.supplyValue = supplyValue;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierCity() {
        return supplierCity;
    }

    public void setSupplierCity(String supplierCity) {
        this.supplierCity = supplierCity;
    }

    public int getSupplyValue() {
        return supplyValue;
    }

    public void setSupplyValue(int supplyValue) {
        this.supplyValue = supplyValue;
    }

    @Override
    public String toString() {
        return "Supplier{" +
                "supplierId='" + supplierId + '\'' +
                ", supplierName='" + supplierName + '\'' +
                ", supplierCity='" + supplierCity + '\'' +
                ", supplyValue=" + supplyValue +
                '}';
    }
}
public class LambdaExprSample2 {
    public static void main(String[] args) {
        List<Supplier> suppliers = new ArrayList<Supplier>();

        suppliers.add(new Supplier("S003","Zeenat","Faridabad",30000));
        suppliers.add(new Supplier("S001","Amarendra","Ahmedabad",40000));
        suppliers.add(new Supplier("S002","David","Chennai",20000));
        suppliers.add(new Supplier("S004","Chandu","Bangalore",10000));

        Collections.sort(suppliers,(s1,s2) -> { return s1.supplierId.compareTo(s2.supplierId); });
        System.out.println("Suppliers Sorted By Id..");
        for(Supplier s:suppliers)
        {
            System.out.println(s);
        }
        System.out.println("-----------------------------------");
        Collections.sort(suppliers,(s1,s2) -> { return s1.supplierCity.compareTo(s2.supplierCity); });
        System.out.println("Suppliers Sorted By SupplierCity..");
        for(Supplier s:suppliers)
        {
            System.out.println(s);
        }
        System.out.println("-----------------------------------");
        Collections.sort(suppliers,(s1,s2) -> { return s1.supplierName.compareTo(s2.supplierName); });
        System.out.println("Suppliers Sorted By SupplierName..");
        for(Supplier s:suppliers)
        {
            System.out.println(s);
        }
    }
}
