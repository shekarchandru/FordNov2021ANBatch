package com.ford.java8;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FilterOperations {

    void mapProgrammers() {

        Function<Programmer, String> getProgrammerName = p -> p.getName();

        Programmer.programmers()
                .stream()
                .map(getProgrammerName)
//                .map(Programmer::getName)
                .forEach(System.out::println);

        Stream <String> pStream = Programmer.programmers()
                                           .stream()
                                            .map(getProgrammerName);
        List<String> proNameList = pStream.collect(Collectors.toList());
        System.out.println(proNameList);
    }

    public static void main(String[] args) {
        FilterOperations fo = new FilterOperations();
        fo.mapProgrammers();
    }

}
