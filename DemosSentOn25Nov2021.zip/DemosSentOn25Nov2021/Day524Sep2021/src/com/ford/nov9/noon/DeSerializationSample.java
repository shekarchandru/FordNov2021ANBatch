package com.ford.nov9.noon;

import java.io.*;

public class DeSerializationSample {

    ObjectInputStream oiStream;
    boolean flag = false;
    Employee[] myemployees;
    File file1;

    public boolean deSerializeEmployeeObject(){
        file1 = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Batch04-01Nov2021AN\\Files\\employees.txt");
        /*
        Employee employee = (Employee)oiStream.readObject();
        ArrayList <Employee> employees = (ArrayList <Employee>)oiStream.readObject();
         */
        try {
            oiStream = new ObjectInputStream(new FileInputStream(file1));
            myemployees = (Employee[])oiStream.readObject();
            System.out.println("The DeSerialized Objects are ");
            for(int i=0;i<myemployees.length;i++)
            {
                System.out.println(myemployees[i]);
            }
            oiStream.close();
            flag = true;
        }
        catch(ClassNotFoundException cnfe)
        {
            cnfe.printStackTrace();
            flag = false;
        }
        catch(FileNotFoundException fnfe) {
            fnfe.printStackTrace();
            flag = false;
        }
        catch (IOException e) {
            e.printStackTrace();
            flag = false;
        }

        return flag;
    }

}
