package com.ford.anoon;

public class EmployeeNew {
    double grossSalary,nettSalary;
    public void calculateSalary(int basic, int hra,int cca, double allowance)
    {
        grossSalary = (basic + hra + cca)+((allowance/100)* basic);
        System.out.println("The Gross Salary is "+grossSalary);
    }
    public void calculateSalary(int basic, int hra,int cca, double allowance,double deductions )
    {
      grossSalary =    (basic + hra + cca)+((allowance/100)* basic);
        nettSalary = grossSalary - ((deductions/100)*basic);
        System.out.println("The Nett Salary is "+nettSalary);
    }
    public void calculateSalary(int basic, int hra,int cca, double allowance,double deductions,String empName )
    {
        grossSalary =    (basic + hra + cca)+((allowance/100)* basic);
        nettSalary = grossSalary - ((deductions/100)*basic);
        System.out.println("the Gross Salary is "+grossSalary+" For the Employee "+empName);
        System.out.println("The Nett Salary is "+nettSalary+" For the  Employee "+empName);
    }

    public static void main(String[] args) {
        EmployeeNew employee = new EmployeeNew();
        System.out.println("Invoking cal salary function with basic,hra,cca,allowance");
        employee.calculateSalary(1000,350,250,12.3);
        System.out.println("-----------------------------");
        System.out.println("Invoking cal salary function with basic,hra,cca,allowance & Deductions");

        employee.calculateSalary(1000,350,250,12.3,10.3);
        System.out.println("-----------------------------");
        System.out.println("Invoking cal salary function with basic,hra,cca,allowance & Deductions with employeeName");
        employee.calculateSalary(1000,267,345,13.4,11.0,"Harsha");
    }
}
