package com.ford.nov12.anoon.functional;

import java.util.ArrayList;
import java.util.Collections;

public class LambdaExprSample2 {
    public static void main(String[] args) {

        ArrayList <Supplier> suppliers = new ArrayList<Supplier>();

        suppliers.add(new Supplier("S005","Zeenat","Faridabad",30000));
        suppliers.add(new Supplier("S006","Amarendar","Ahmedabad",60000));
        suppliers.add(new Supplier("S004","Yasmeen","Bangalore",10000));
        suppliers.add(new Supplier("S001","Chandu","Hyderabad",50000));
        suppliers.add(new Supplier("S003","Emanuel","Chennai",40000));
        suppliers.add(new Supplier("S002","David","Mangalore",38000));

        System.out.println("----------------------Suppliers Sorted by Id-----------------------");
        Collections.sort(suppliers,(s1,s2) -> {
            return s1.supplierId.compareTo(s2.supplierId);
        });
        for(Supplier s:suppliers)
        {
            System.out.println(s);
        }
        System.out.println("---------------------------Suppliers Sorted by Name-------------------------------");
        Collections.sort(suppliers,(x,y) -> {
            return x.supplierName.compareTo(y.supplierName);
        });
        for(Supplier s : suppliers)
        {
            System.out.println(s);
        }
        System.out.println("---------------------------Suppliers Sorted by City-------------------------------");
        Collections.sort(suppliers,(s1,s2) -> {
            return s1.supplierCity.compareTo(s2.supplierCity);
        });
        for(Supplier s:suppliers)
        {
            System.out.println(s);
        }
        System.out.println("---------------------------Suppliers Sorted by SupplyValue-------------------------------");
        Collections.sort(suppliers,(s1,s2) -> {

            return Integer.compare(s1.supplyValue,s2.supplyValue);
        });
        for(Supplier s:suppliers)
        {
            System.out.println(s);
        }
    }
}
