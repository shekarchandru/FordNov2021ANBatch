package com.ford.nov12.anoon.functional;

public interface NewCustomer {

    public double calculateInvoiceAmt(int qty,int price);
}
