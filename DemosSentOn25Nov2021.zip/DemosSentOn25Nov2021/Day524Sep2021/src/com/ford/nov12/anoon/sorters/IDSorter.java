package com.ford.nov12.anoon.sorters;


import java.util.Comparator;

public class IDSorter implements Comparator<Customer> {
    @Override
    public int compare(Customer o1, Customer o2) {
        if(o1.customerId.compareTo(o2.customerId) > 0)
        {
            return 1;
        }
        else  if(o1.customerId.compareTo(o2.customerId) < 0)
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }
}
