package com.ford.nov10.morn;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class HashTableSample {

    Hashtable <String,Employee> myHashTable;
    boolean flag ;

    public HashTableSample()
    {
        flag = false;
        myHashTable = new Hashtable<String,Employee>();
        myHashTable.put("E001",new Employee("E001","Harsha","RTNagar","9848848848",10000));
        myHashTable.put("E002",new Employee("E002","Kiran","Jayanagar","9848864548",11000));
        myHashTable.put("E003",new Employee("E003","Suman Kumar","Vijayanagar","9345848848",12000));
        myHashTable.put("E004",new Employee("E004","Sreejith","Malleswaram","9848878948",13000));
        myHashTable.put("E005",new Employee("E005","Mahesh Kumar","Koramangala","9843548848",14000));
    }
    public boolean getHashTableData()
    {

       Enumeration myKeys =  myHashTable.keys();

       try {
           while (myKeys.hasMoreElements()) {
               String myKey = (String) myKeys.nextElement();
               System.out.println("The Value Object for the Key " + myKey + " is " + myHashTable.get(myKey));
           }
           flag = true;
       }
       catch(Exception exc)
       {
           exc.printStackTrace();
           flag = false;
       }
        return flag;
    }
    public Employee getEmployeeByKey(String keyStr)
    {
        Employee employee = myHashTable.get(keyStr);
     /*  if( employee == null)
        {
            flag = false;
        }
        else
        {
            flag = true;
        }*/
        System.out.println(employee);
        return employee;
    }
    public boolean getHashTableValues()
    {
        Collection collection = myHashTable.values();

        System.out.println("The Values in Hashtable are...");
        try {
            Iterator<Employee> valuesIter = collection.iterator();
            while (valuesIter.hasNext()) {
                Employee e = valuesIter.next();
                System.out.println(e);
                flag = true;
            }
        }
        catch(Exception exc)
        {
            exc.printStackTrace();
            flag = false;
        }
        return  flag;
    }


}
