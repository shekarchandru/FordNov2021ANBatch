package com.ford.sep27;

public interface InsuranceInterface extends BankingInterface,Taxation{

    public void createPolicy();
    public void terminatePolicy();
    public void calculatePremium();
}
